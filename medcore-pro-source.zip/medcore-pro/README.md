# MedCore Pro — واجهة إدارة عيادة طبية

واجهة أمامية (Frontend فقط) لتطبيق عيادة طبية، عربية بالكامل واتجاه RTL.
جميع البيانات **وهمية** ومكتوبة داخل `src/data/mockData.js` — لا يوجد Backend ولا Supabase ولا Firebase.

## التقنيات
React 18 · Vite 5 · Tailwind CSS 3 · React Router 6 · Lucide React

---

## التشغيل محلياً

```bash
npm install
npm run dev      # http://localhost:5173
```

## البناء

```bash
npm run build    # ينتج مجلد dist
npm run preview  # معاينة نسخة الإنتاج
```

---

## النشر على Netlify

### لماذا ظهر خطأ Page not found؟

Netlify Drop **يقبل ملفات مبنيّة جاهزة فقط** — لا يقبل الكود المصدري ولا يبني المشروع نيابة عنك.
الخطأ يظهر حين لا يجد `index.html` في جذر ما رفعته، أي عند سحب مجلد المشروع كاملاً
أو ملف ZIP يحتوي مجلداً فرعياً مثل `medcore-pro/` أو `dist/` بداخله.

### الطريقة الأولى — سحب مجلد dist (الأسرع)

```bash
npm install
npm run build
```

ثم افتح [app.netlify.com/drop](https://app.netlify.com/drop) واسحب **مجلد `dist` نفسه** — لا مجلد المشروع.

### إنشاء ZIP جاهز للنشر (المحتوى في الجذر مباشرة)

**macOS / Linux:**

```bash
npm install
npm run build
cd dist && zip -r ../medcore-pro-netlify.zip . && cd ..
```

**Windows (PowerShell):**

```powershell
npm install
npm run build
Compress-Archive -Path dist\* -DestinationPath medcore-pro-netlify.zip -Force
```

الأمران `cd dist` و `dist\*` هما ما يضعان `index.html` في جذر ملف ZIP.
تحقق قبل الرفع أن محتوى ZIP هو:

```
index.html
assets/
_redirects
```

وليس `dist/index.html` ولا `medcore-pro/dist/index.html`.

### الطريقة الثانية — ربط Git (بناء تلقائي)

ارفع المشروع إلى GitHub ثم اربطه بـ Netlify. الإعدادات تُقرأ تلقائياً من `netlify.toml`:
أمر البناء `npm run build`، مجلد النشر `dist`، إصدار Node 20.

### حماية مزدوجة ضد Page not found

| الإجراء | الملف |
|---|---|
| `HashRouter` — المسارات بعد `#` فلا يطلب المتصفح أي مسار من الخادم | `src/App.jsx` |
| `base: './'` — روابط نسبية تعمل من أي مجلد | `vite.config.js` |
| `/*  /index.html  200` — يُنسخ تلقائياً إلى `dist/` | `public/_redirects` |
| إعادة توجيه SPA وإعدادات البناء | `netlify.toml` |

بهذا يعمل المشروع على Netlify و Vercel و GitHub Pages و Cloudflare Pages،
بل ويعمل بفتح `dist/index.html` مباشرة من القرص.

---

## الصفحات

| المسار | الصفحة |
|---|---|
| `/` | لوحة التحكم |
| `/patients` | المرضى |
| `/patients/:id` | **ملف المريض — الشاشة المحورية** |
| `/waiting` | قائمة الانتظار |
| `/visits` | الزيارات |
| `/visits/new` | زيارة جديدة |
| `/appointments` | المواعيد |
| `/prescriptions` | الوصفات |
| `/labs` | الفحوصات والمرفقات |
| `/reports` | التقارير |
| `/settings` | الإعدادات |

جميع الصفحات التسع مرتبطة بالشريط الجانبي، وأي مسار غير معروف يعود إلى لوحة التحكم.

## البنية

```
src/
├── data/mockData.js      # كل البيانات الوهمية (12 مريضاً، زيارات، وصفات، فحوصات…)
├── components/
│   ├── ui.jsx            # مكتبة المكونات (Button, Card, Badge, Modal, Charts…)
│   ├── Sidebar.jsx       # الشريط الجانبي
│   ├── Topbar.jsx        # الشريط العلوي والبحث
│   └── Layout.jsx        # الهيكل العام + نموذج مريض جديد
├── pages/                # الصفحات الإحدى عشرة
├── App.jsx               # المسارات
├── main.jsx              # نقطة الدخول
└── index.css             # الأنماط الأساسية وخط الأرقام
```

## الهوية البصرية

| العنصر | القيمة |
|---|---|
| كحلي عميق | `#0A2540` / `#06182B` |
| تركواز طبي | `#12A5A5` |
| ذهبي (للأزرار المهمة فقط) | `#C9A227` |
| رمادي ناعم (الخلفية) | `#F4F7FA` |
| أحمر التنبيه | `#C2454A` |
| العناوين | Cairo |
| النصوص | IBM Plex Sans Arabic |
| الأرقام | IBM Plex Mono (صنف `.num`) |

عدّل `tailwind.config.js` → `theme.extend.colors` لتغيير الهوية كلها.

---
نسخة عرض. البيانات تجريبية ولا تخص أشخاصاً حقيقيين.
