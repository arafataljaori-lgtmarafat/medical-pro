import { HashRouter, Navigate, Route, Routes } from 'react-router-dom'
import Layout from './components/Layout'
import { ToastHost } from './components/ui'
import Dashboard from './pages/Dashboard'
import Patients from './pages/Patients'
import PatientProfile from './pages/PatientProfile'
import Waiting from './pages/Waiting'
import Visits from './pages/Visits'
import NewVisit from './pages/NewVisit'
import Appointments from './pages/Appointments'
import Prescriptions from './pages/Prescriptions'
import Labs from './pages/Labs'
import Reports from './pages/Reports'
import Settings from './pages/Settings'

export default function App() {
  return (
    <ToastHost>
      <HashRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="patients" element={<Patients />} />
            <Route path="patients/:id" element={<PatientProfile />} />
            <Route path="waiting" element={<Waiting />} />
            <Route path="visits" element={<Visits />} />
            <Route path="visits/new" element={<NewVisit />} />
            <Route path="appointments" element={<Appointments />} />
            <Route path="prescriptions" element={<Prescriptions />} />
            <Route path="labs" element={<Labs />} />
            <Route path="reports" element={<Reports />} />
            <Route path="settings" element={<Settings />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </HashRouter>
    </ToastHost>
  )
}
