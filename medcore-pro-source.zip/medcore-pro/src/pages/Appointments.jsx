import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { CalendarDays, Plus, Clock, DoorOpen, Phone, ChevronRight, ChevronLeft, CalendarClock } from 'lucide-react'
import { PageHeader } from '../components/Layout'
import { Avatar, Badge, Button, Card, CardHead, Empty, Field, Input, Modal, Select, statusTone, useToast } from '../components/ui'
import { appointments, patients } from '../data/mockData'

const WEEK = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']
const TODAY = '2026-07-17'

// يوليو 2026 يبدأ يوم الأربعاء (الفهرس 3 حين يكون الأحد أول أيام الأسبوع)
const FIRST_WEEKDAY = 3
const DAYS_IN_MONTH = 31
const iso = (d) => `2026-07-${String(d).padStart(2, '0')}`

export default function Appointments() {
  const nav = useNavigate()
  const toast = useToast()
  const [selected, setSelected] = useState(TODAY)
  const [open, setOpen] = useState(false)

  const byDay = useMemo(() => {
    const m = {}
    appointments.forEach((a) => {
      m[a.date] = m[a.date] || []
      m[a.date].push(a)
    })
    return m
  }, [])

  const dayList = (byDay[selected] || []).sort((a, b) => a.time.localeCompare(b.time))
  const upcoming = appointments
    .filter((a) => a.date > TODAY)
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time))

  return (
    <>
      <PageHeader
        eyebrow="الجدول"
        title="المواعيد"
        sub="اليوم به 8 مواعيد. اضغط أي يوم في التقويم لعرض جدوله."
        actions={<Button variant="gold" icon={Plus} onClick={() => setOpen(true)}>إضافة موعد</Button>}
      />

      <div className="grid gap-4 lg:grid-cols-[340px_1fr]">
        {/* التقويم */}
        <div className="space-y-4">
          <Card>
            <div className="flex items-center justify-between px-5 py-4">
              <button className="grid h-8 w-8 place-items-center rounded-lg border border-line text-navy-400 hover:bg-mist" aria-label="الشهر السابق">
                <ChevronRight size={15} />
              </button>
              <div className="text-center">
                <p className="font-display text-[15px] font-bold text-navy-950">يوليو 2026</p>
                <p className="num text-[11px] text-navy-300">{appointments.length} موعداً هذا الشهر</p>
              </div>
              <button className="grid h-8 w-8 place-items-center rounded-lg border border-line text-navy-400 hover:bg-mist" aria-label="الشهر التالي">
                <ChevronLeft size={15} />
              </button>
            </div>

            <div className="border-t border-line p-4">
              <div className="mb-2 grid grid-cols-7 gap-1">
                {WEEK.map((d) => (
                  <span key={d} className="py-1 text-center text-[10px] font-semibold text-navy-300">{d.slice(0, 3)}</span>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {Array.from({ length: FIRST_WEEKDAY }).map((_, i) => <span key={`b${i}`} />)}
                {Array.from({ length: DAYS_IN_MONTH }).map((_, i) => {
                  const d = i + 1
                  const date = iso(d)
                  const count = (byDay[date] || []).length
                  const on = selected === date
                  const isToday = date === TODAY
                  return (
                    <button
                      key={d}
                      onClick={() => setSelected(date)}
                      className={`relative aspect-square rounded-lg text-[12.5px] transition-colors ${
                        on ? 'bg-navy-950 font-bold text-white' : isToday ? 'bg-teal-50 font-bold text-teal-700' : 'text-navy-600 hover:bg-mist'
                      }`}
                    >
                      <span className="num">{d}</span>
                      {count > 0 && (
                        <span className={`absolute bottom-1.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full ${on ? 'bg-teal-300' : 'bg-gold-400'}`} />
                      )}
                    </button>
                  )
                })}
              </div>
            </div>

            <div className="flex items-center gap-4 border-t border-line px-5 py-3 text-[11px] text-navy-400">
              <span className="flex items-center gap-1.5"><i className="h-1.5 w-1.5 rounded-full bg-gold-400" /> يوم به مواعيد</span>
              <span className="flex items-center gap-1.5"><i className="h-1.5 w-1.5 rounded-full bg-teal-500" /> اليوم</span>
            </div>
          </Card>

          {/* حالات الموعد */}
          <Card className="p-5">
            <p className="eyebrow mb-3">حالات المواعيد اليوم</p>
            <div className="space-y-2.5">
              {['حضر', 'مكتمل', 'مؤكد', 'مؤجل', 'لم يحضر'].map((s) => {
                const n = (byDay[TODAY] || []).filter((a) => a.status === s).length
                return (
                  <div key={s} className="flex items-center gap-3">
                    <Badge tone={statusTone(s)} className="w-20 justify-center">{s}</Badge>
                    <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-navy-50">
                      <div className="h-full rounded-full bg-navy-900" style={{ width: `${(n / 8) * 100}%` }} />
                    </div>
                    <span className="num w-4 text-left text-[12px] font-semibold text-navy-600">{n}</span>
                  </div>
                )
              })}
            </div>
          </Card>
        </div>

        {/* جدول اليوم + القادم */}
        <div className="space-y-4">
          <Card>
            <CardHead
              title={selected === TODAY ? 'مواعيد اليوم' : `مواعيد ${selected}`}
              sub={`${dayList.length} موعداً — الجدول من 09:00 إلى 13:00`}
              icon={CalendarDays}
              action={<Button size="sm" variant="outline" icon={Plus} onClick={() => setOpen(true)}>إضافة</Button>}
            />
            <div className="border-t border-line">
              {dayList.length === 0 ? (
                <Empty icon={CalendarDays} title="لا مواعيد في هذا اليوم" body="اليوم فارغ تماماً. أضف موعداً أو اختر يوماً آخر من التقويم." action={<Button variant="outline" onClick={() => setOpen(true)}>إضافة موعد</Button>} />
              ) : (
                dayList.map((a) => (
                  <div key={a.id} className="flex flex-col gap-3 border-b border-line px-5 py-4 last:border-0 hover:bg-mist sm:flex-row sm:items-center">
                    {/* الوقت */}
                    <div className="flex w-20 shrink-0 flex-row items-center gap-2 sm:flex-col sm:items-start">
                      <span className="num text-[15px] font-bold text-navy-950">{a.time}</span>
                      <span className="num text-[11px] text-navy-300">{a.duration} دقيقة</span>
                    </div>

                    <span className="hidden h-10 w-px bg-line sm:block" />

                    <div className="flex min-w-0 flex-1 items-center gap-3">
                      <Avatar initials={a.initials} size="sm" />
                      <div className="min-w-0">
                        <p className="truncate text-[13.5px] font-bold text-navy-900">{a.name}</p>
                        <p className="text-[12px] text-navy-400">{a.type}</p>
                      </div>
                    </div>

                    <div className="flex shrink-0 items-center gap-3">
                      <span className="num hidden items-center gap-1 text-[12px] text-navy-400 md:flex"><DoorOpen size={12} />{a.room}</span>
                      <Badge tone={statusTone(a.status)}>{a.status}</Badge>
                      <Button size="sm" variant="outline" onClick={() => nav(`/patients/${a.patientId}`)}>الملف</Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </Card>

          <Card>
            <CardHead title="مواعيد قادمة" sub="بعد اليوم — مرتبة زمنياً" icon={CalendarClock} />
            <div className="grid gap-px border-t border-line bg-line sm:grid-cols-2">
              {upcoming.map((a) => (
                <button key={a.id} onClick={() => setSelected(a.date)} className="bg-white p-4 text-right hover:bg-mist">
                  <div className="flex items-center justify-between">
                    <span className="num text-[12.5px] font-bold text-navy-900">{a.date}</span>
                    <span className="num flex items-center gap-1 text-[12px] text-navy-400"><Clock size={11} />{a.time}</span>
                  </div>
                  <div className="mt-3 flex items-center gap-2.5">
                    <Avatar initials={a.initials} size="sm" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-semibold text-navy-900">{a.name}</p>
                      <p className="text-[11.5px] text-navy-400">{a.type}</p>
                    </div>
                    <a href={`tel:${a.phone}`} className="grid h-8 w-8 place-items-center rounded-lg border border-line text-navy-400 hover:bg-white" aria-label="اتصال">
                      <Phone size={13} />
                    </a>
                  </div>
                </button>
              ))}
            </div>
          </Card>
        </div>
      </div>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="إضافة موعد"
        sub="سيصل المريض تذكيراً نصياً قبل الموعد بيوم."
        footer={
          <>
            <Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button variant="gold" onClick={() => { setOpen(false); toast('أُضيف الموعد إلى الجدول') }}>إضافة الموعد</Button>
          </>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="المريض" required className="sm:col-span-2">
            <Select defaultValue="">
              <option value="" disabled>اختر من السجل</option>
              {patients.map((p) => <option key={p.id} value={p.id}>{p.name} — {p.phone}</option>)}
            </Select>
          </Field>
          <Field label="التاريخ" required><Input type="date" defaultValue={selected} /></Field>
          <Field label="الوقت" required><Input type="time" defaultValue="10:00" /></Field>
          <Field label="نوع الموعد">
            <Select defaultValue="متابعة">
              {['كشف أول', 'متابعة', 'متابعة عاجلة', 'نتائج', 'إجراء'].map((t) => <option key={t}>{t}</option>)}
            </Select>
          </Field>
          <Field label="المدة">
            <Select defaultValue="20">
              {[15, 20, 30, 45, 60].map((d) => <option key={d} value={d}>{d} دقيقة</option>)}
            </Select>
          </Field>
          <Field label="الغرفة" className="sm:col-span-2">
            <Select defaultValue="غرفة 1">
              {['غرفة 1', 'غرفة 2', 'غرفة 3'].map((r) => <option key={r}>{r}</option>)}
            </Select>
          </Field>
        </div>
      </Modal>
    </>
  )
}
