import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import {
  ChevronRight, Phone, Fingerprint, Droplet, ShieldAlert, Activity, Pill, FlaskConical,
  CalendarPlus, Stethoscope, FileText, NotebookPen, Paperclip, Image, Printer,
  HeartPulse, Thermometer, Wind, Scale, Gauge, Sparkles, ClipboardList, MapPin,
  CircleDot, Share2, Download,
} from 'lucide-react'
import { Avatar, Badge, Button, Card, CardHead, Empty, Modal, Sparkline, Textarea, statusTone, useToast } from '../components/ui'
import { attachments, labOrders, patients, prescriptions, visitsByPatient, clinic } from '../data/mockData'

const TABS = [
  { key: 'overview', label: 'نظرة عامة', icon: Sparkles },
  { key: 'visits', label: 'الزيارات', icon: Stethoscope },
  { key: 'rx', label: 'الوصفات', icon: Pill },
  { key: 'labs', label: 'الفحوصات', icon: FlaskConical },
  { key: 'files', label: 'المرفقات', icon: Paperclip },
]

const visitTypeTone = { 'كشف أول': 'gold', 'متابعة': 'teal', 'طارئ': 'danger' }

// ------------------------------------------------------------
// الشريط الحيوي — العنصر المميز في هذه الشاشة
// ------------------------------------------------------------
function VitalCell({ icon: Icon, label, value, unit, tone = 'normal' }) {
  const color = { normal: 'text-teal-300', warn: 'text-gold-300', bad: 'text-[#FF8A8E]' }[tone]
  return (
    <div className="relative flex-1 px-4 py-3.5 sm:px-5">
      <span className="flex items-center gap-1.5 text-[10.5px] font-medium text-navy-300/70">
        <Icon size={12} strokeWidth={1.8} />
        {label}
      </span>
      <p className="mt-1 flex items-baseline gap-1">
        <span className={`num text-[19px] font-semibold leading-none ${color}`}>{value}</span>
        {unit && <span className="text-[10px] text-navy-300/60">{unit}</span>}
      </p>
    </div>
  )
}

function VitalsStrip({ v }) {
  const bpSys = parseInt(v.bp)
  return (
    <div className="relative overflow-hidden border-t border-white/[0.07]">
      {/* خط مسح خفيف يوحي بشاشة مراقبة حية */}
      <div className="pointer-events-none absolute inset-y-0 w-24 animate-sweep bg-gradient-to-l from-transparent via-teal-400/[0.07] to-transparent" />
      <div className="relative flex flex-wrap divide-x divide-x-reverse divide-white/[0.07]">
        <VitalCell icon={Gauge} label="ضغط الدم" value={v.bp} unit="ملم زئبق" tone={bpSys >= 140 ? 'bad' : bpSys >= 130 ? 'warn' : 'normal'} />
        <VitalCell icon={HeartPulse} label="النبض" value={v.hr} unit="نبضة/د" tone={v.hr > 90 ? 'warn' : 'normal'} />
        <VitalCell icon={Thermometer} label="الحرارة" value={v.temp} unit="°م" />
        <VitalCell icon={Wind} label="الأكسجين" value={v.spo2} unit="%" tone={v.spo2 < 95 ? 'bad' : 'normal'} />
        <VitalCell icon={Droplet} label="السكر" value={v.sugar} unit="ملغ/دل" tone={v.sugar > 180 ? 'bad' : v.sugar > 140 ? 'warn' : 'normal'} />
        <VitalCell icon={Scale} label="كتلة الجسم" value={v.bmi} tone={v.bmi >= 30 ? 'warn' : 'normal'} />
      </div>
    </div>
  )
}

// ------------------------------------------------------------
// أعلام حرجة — دائمة الظهور
// ------------------------------------------------------------
function Flag({ icon: Icon, title, items, tone }) {
  const map = {
    danger: 'border-[#F0D2D3] bg-[#FDF4F4] text-clay',
    navy: 'border-navy-100 bg-navy-50/60 text-navy-700',
    teal: 'border-teal-100 bg-teal-50/60 text-teal-700',
  }
  return (
    <div className={`rounded-2xl border p-4 ${map[tone]}`}>
      <p className="flex items-center gap-2 text-[12px] font-bold">
        <Icon size={14} strokeWidth={2} />
        {title}
      </p>
      <ul className="mt-2.5 space-y-1.5">
        {items.length === 0 ? (
          <li className="text-[12.5px] text-navy-400">لا شيء مسجّل</li>
        ) : (
          items.map((t, i) => (
            <li key={i} className="flex gap-2 text-[12.5px] leading-relaxed text-navy-700">
              <CircleDot size={11} className="mt-1 shrink-0 opacity-40" />
              <span>{t}</span>
            </li>
          ))
        )}
      </ul>
    </div>
  )
}

// ------------------------------------------------------------
export default function PatientProfile() {
  const { id } = useParams()
  const nav = useNavigate()
  const toast = useToast()
  const [tab, setTab] = useState('overview')
  const [noteOpen, setNoteOpen] = useState(false)
  const p = patients.find((x) => x.id === id)

  if (!p)
    return (
      <Card>
        <Empty icon={ShieldAlert} title="هذا الملف غير موجود" body="ربما حُذف الرقم أو تغيّر. عد إلى قائمة المرضى واختر من هناك." action={<Button onClick={() => nav('/patients')}>قائمة المرضى</Button>} />
      </Card>
    )

  const pVisits = visitsByPatient(p.id)
  const pRx = prescriptions.filter((r) => r.patientId === p.id)
  const pLabs = labOrders.filter((l) => l.patientId === p.id)
  const pFiles = attachments.filter((f) => f.patientId === p.id)
  const lastVisit = pVisits[0]
  const hasAllergy = !p.allergies[0]?.includes('لا توجد')

  return (
    <>
      {/* مسار التنقل */}
      <nav className="mb-4 flex items-center gap-1.5 text-[12.5px] text-navy-400">
        <Link to="/patients" className="hover:text-navy-700">المرضى</Link>
        <ChevronRight size={13} className="rotate-180" />
        <span className="font-semibold text-navy-700">{p.name}</span>
      </nav>

      {/* ===== بطاقة الهوية + الشريط الحيوي ===== */}
      <section className="overflow-hidden rounded-2xl bg-navy-950 grid-texture shadow-lift">
        <div className="flex flex-col gap-5 p-5 sm:p-6 lg:flex-row lg:items-start">
          <Avatar initials={p.initials} size="xl" ring className="ring-offset-navy-950" />

          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2.5">
              <h1 className="font-display text-[22px] font-extrabold leading-tight text-white sm:text-[26px]">{p.name}</h1>
              {p.risk === 'مرتفع' && <Badge tone="danger" dot>خطورة مرتفعة</Badge>}
              <Badge tone="slate" className="!border-white/15 !bg-white/[0.06] !text-navy-200">{p.status}</Badge>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-[12.5px] text-navy-200/80">
              <span className="num flex items-center gap-1.5"><Fingerprint size={13} className="text-teal-400/70" />{p.id}</span>
              <span className="num flex items-center gap-1.5"><Activity size={13} className="text-teal-400/70" />{p.age} سنة · {p.gender}</span>
              <span className="num flex items-center gap-1.5"><Droplet size={13} className="text-teal-400/70" />{p.blood}</span>
              <a href={`tel:${p.phone}`} className="num flex items-center gap-1.5 hover:text-white"><Phone size={13} className="text-teal-400/70" />{p.phone}</a>
              <span className="flex items-center gap-1.5"><MapPin size={13} className="text-teal-400/70" />{p.city}</span>
              <span className="flex items-center gap-1.5"><ShieldAlert size={13} className="text-teal-400/70" />{p.insurance}</span>
            </div>

            {/* الأزرار */}
            <div className="mt-5 flex flex-wrap gap-2">
              <Button variant="gold" size="sm" icon={Stethoscope} onClick={() => nav('/visits/new')}>إضافة زيارة</Button>
              <Button size="sm" icon={Pill} onClick={() => nav('/prescriptions')} className="!border-white/15 !bg-white/[0.08] hover:!bg-white/[0.14]">إضافة وصفة</Button>
              <Button size="sm" icon={FlaskConical} onClick={() => nav('/labs')} className="!border-white/15 !bg-white/[0.08] hover:!bg-white/[0.14]">طلب فحوصات</Button>
              <Button size="sm" icon={CalendarPlus} onClick={() => { toast('تم فتح تحديد موعد المراجعة'); nav('/appointments') }} className="!border-white/15 !bg-white/[0.08] hover:!bg-white/[0.14]">موعد مراجعة</Button>
              <Button size="sm" icon={Printer} onClick={() => toast('تم تجهيز الملف للطباعة', 'gold')} className="!border-white/15 !bg-transparent hover:!bg-white/[0.08]">طباعة الملف</Button>
            </div>
          </div>

          {/* عمود المواعيد */}
          <div className="grid shrink-0 grid-cols-2 gap-3 lg:w-52 lg:grid-cols-1">
            <div className="rounded-xl border border-white/[0.07] bg-white/[0.03] px-3.5 py-3">
              <p className="text-[10.5px] text-navy-300/70">آخر زيارة</p>
              <p className="num mt-1 text-[15px] font-semibold text-white">{p.lastVisit}</p>
            </div>
            <div className="rounded-xl border border-teal-400/20 bg-teal-400/[0.07] px-3.5 py-3">
              <p className="text-[10.5px] text-teal-200/70">المراجعة القادمة</p>
              <p className="num mt-1 text-[15px] font-semibold text-teal-300">{p.nextFollowUp}</p>
            </div>
          </div>
        </div>

        <VitalsStrip v={p.vitals} />
      </section>

      {/* ===== الأعلام الحرجة ===== */}
      <div className="mt-4 grid gap-3 md:grid-cols-3">
        <Flag
          icon={ShieldAlert}
          tone={hasAllergy ? 'danger' : 'navy'}
          title={hasAllergy ? 'حساسية — تحقق قبل أي وصفة' : 'الحساسية'}
          items={p.allergies}
        />
        <Flag icon={Activity} tone="navy" title="الأمراض المزمنة" items={p.chronic} />
        <Flag icon={Pill} tone="teal" title="الأدوية المستمرة" items={p.meds.map((m) => `${m.name} — ${m.freq}`)} />
      </div>

      {/* ===== التبويبات ===== */}
      <div className="mt-6 flex gap-1 overflow-x-auto border-b border-line">
        {TABS.map((t) => {
          const on = tab === t.key
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`relative flex shrink-0 items-center gap-2 px-4 py-3 text-[13.5px] transition-colors ${
                on ? 'font-bold text-navy-950' : 'text-navy-400 hover:text-navy-700'
              }`}
            >
              <t.icon size={15} strokeWidth={on ? 2.1 : 1.7} className={on ? 'text-teal-500' : ''} />
              {t.label}
              {on && <span className="absolute inset-x-3 -bottom-px h-0.5 rounded-full bg-teal-500" />}
            </button>
          )
        })}
      </div>

      {/* ===== محتوى التبويب ===== */}
      <div key={tab} className="mt-4 animate-rise">
        {tab === 'overview' && (
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="space-y-4 lg:col-span-2">
              {/* آخر تشخيص */}
              <Card>
                <CardHead title="آخر تشخيص" sub={lastVisit ? `زيارة ${lastVisit.date} — ${lastVisit.type}` : 'لا توجد زيارات'} icon={ClipboardList} />
                <div className="border-t border-line px-5 py-4">
                  <p className="text-[15px] font-semibold leading-relaxed text-navy-900">{p.lastDiagnosis}</p>
                  {lastVisit && (
                    <div className="mt-4 grid gap-4 sm:grid-cols-2">
                      <div>
                        <p className="eyebrow mb-1.5">الشكوى الرئيسية</p>
                        <p className="text-[13px] leading-relaxed text-navy-600">{lastVisit.complaint}</p>
                      </div>
                      <div>
                        <p className="eyebrow mb-1.5">الخطة العلاجية</p>
                        <p className="text-[13px] leading-relaxed text-navy-600">{lastVisit.plan}</p>
                      </div>
                    </div>
                  )}
                </div>
              </Card>

              {/* المؤشرات */}
              <Card>
                <CardHead title="اتجاه المؤشرات" sub="آخر ستة أشهر — القراءات المسجلة في العيادة" icon={Activity} />
                <div className="grid gap-px border-t border-line bg-line sm:grid-cols-3">
                  {[
                    { label: 'سكر الدم', unit: 'ملغ/دل', data: p.trends.sugar, color: '#12A5A5' },
                    { label: 'الضغط الانقباضي', unit: 'ملم زئبق', data: p.trends.bp, color: '#0A2540' },
                    { label: 'الوزن', unit: 'كغ', data: p.trends.weight, color: '#C9A227' },
                  ].map((m) => {
                    const first = m.data[0]
                    const last = m.data[m.data.length - 1]
                    const diff = last - first
                    return (
                      <div key={m.label} className="bg-white p-4">
                        <p className="text-[12px] font-medium text-navy-400">{m.label}</p>
                        <p className="mt-1 flex items-baseline gap-1.5">
                          <span className="num font-display text-[22px] font-extrabold text-navy-950">{last}</span>
                          <span className="text-[11px] text-navy-300">{m.unit}</span>
                          <span className={`num ms-auto text-[11.5px] font-semibold ${diff > 0 ? 'text-clay' : 'text-teal-600'}`}>
                            {diff > 0 ? '+' : ''}{diff}
                          </span>
                        </p>
                        <div className="mt-2">
                          <Sparkline data={m.data} stroke={m.color} fill={`${m.color}1A`} height={44} />
                        </div>
                        <p className="mt-1 text-[10.5px] text-navy-300">{p.trends.labels[0]} — {p.trends.labels[p.trends.labels.length - 1]}</p>
                      </div>
                    )
                  })}
                </div>
              </Card>

              {/* الخط الزمني المختصر */}
              <Card>
                <CardHead
                  title="مسار الزيارات"
                  sub={`${pVisits.length} زيارة مسجلة`}
                  icon={Stethoscope}
                  action={<Button size="sm" variant="ghost" onClick={() => setTab('visits')}>عرض التفاصيل</Button>}
                />
                <div className="border-t border-line px-5 py-5">
                  <Timeline visits={pVisits} compact />
                </div>
              </Card>
            </div>

            {/* العمود الجانبي */}
            <div className="space-y-4">
              {/* ملاحظات الطبيب */}
              <Card className="border-gold-200 bg-gold-50/40">
                <CardHead
                  title="ملاحظات مهمة للطبيب"
                  sub="لا تظهر للسكرتارية"
                  icon={NotebookPen}
                  action={<Button size="sm" variant="outline" onClick={() => setNoteOpen(true)}>تحرير</Button>}
                />
                <div className="border-t border-gold-200/70 px-5 py-4">
                  <p className="text-[13px] leading-[1.9] text-navy-700">{p.doctorNotes}</p>
                </div>
              </Card>

              {/* آخر وصفة */}
              <Card>
                <CardHead title="آخر وصفة" sub={pRx[0] ? `${pRx[0].id} · ${pRx[0].date}` : '—'} icon={Pill} />
                <div className="border-t border-line">
                  {pRx[0] ? (
                    <>
                      {pRx[0].items.map((it, i) => (
                        <div key={i} className="border-b border-line px-5 py-3 last:border-0">
                          <p className="text-[13px] font-semibold text-navy-900">{it.drug}</p>
                          <p className="mt-0.5 text-[12px] text-navy-400">{it.dose} · {it.freq} · {it.duration}</p>
                        </div>
                      ))}
                      <div className="px-5 py-3">
                        <Button size="sm" variant="outline" icon={FileText} onClick={() => nav('/prescriptions')} className="w-full">
                          فتح الوصفة
                        </Button>
                      </div>
                    </>
                  ) : (
                    <Empty icon={Pill} title="لا توجد وصفات" body="أنشئ أول وصفة لهذا المريض من زر إضافة وصفة." />
                  )}
                </div>
              </Card>

              {/* آخر فحوصات */}
              <Card>
                <CardHead title="آخر الفحوصات" sub={`${pLabs.length} طلب`} icon={FlaskConical} />
                <div className="border-t border-line">
                  {pLabs.length ? (
                    pLabs.slice(0, 4).map((l) => (
                      <div key={l.id} className="flex items-center gap-3 border-b border-line px-5 py-3 last:border-0">
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[13px] font-semibold text-navy-900">{l.test}</p>
                          <p className="num text-[11.5px] text-navy-400">{l.ordered} · {l.result}</p>
                        </div>
                        <Badge tone={statusTone(l.flag === '—' ? l.status : l.flag)}>{l.flag === '—' ? l.status : l.flag}</Badge>
                      </div>
                    ))
                  ) : (
                    <Empty icon={FlaskConical} title="لا توجد فحوصات" body="اطلب أول فحص من زر طلب فحوصات." />
                  )}
                </div>
              </Card>
            </div>
          </div>
        )}

        {tab === 'visits' && (
          <Card>
            <CardHead title="سجل الزيارات الكامل" sub="من الأحدث إلى الأقدم — كل زيارة بتفاصيلها" icon={Stethoscope} action={<Button size="sm" variant="gold" icon={Stethoscope} onClick={() => nav('/visits/new')}>زيارة جديدة</Button>} />
            <div className="border-t border-line px-5 py-6">
              {pVisits.length ? <Timeline visits={pVisits} /> : <Empty icon={Stethoscope} title="لم تُسجّل زيارات بعد" body="أول زيارة تبني السجل الطبي لهذا المريض." action={<Button variant="gold" onClick={() => nav('/visits/new')}>بدء زيارة</Button>} />}
            </div>
          </Card>
        )}

        {tab === 'rx' && (
          <div className="space-y-4">
            {pRx.length ? (
              pRx.map((r) => (
                <Card key={r.id}>
                  <CardHead
                    title={r.diagnosis}
                    sub={`${r.id} · ${r.date} · ${r.doctor}`}
                    icon={Pill}
                    action={<Badge tone={r.status === 'مصروفة' ? 'green' : r.status === 'مسودة' ? 'slate' : 'gold'}>{r.status}</Badge>}
                  />
                  <div className="overflow-x-auto border-t border-line">
                    <table className="w-full text-right">
                      <thead>
                        <tr className="bg-mist text-[11.5px] text-navy-400">
                          <th className="px-5 py-2.5 font-semibold">الدواء</th>
                          <th className="px-3 py-2.5 font-semibold">الجرعة</th>
                          <th className="px-3 py-2.5 font-semibold">عدد المرات</th>
                          <th className="px-3 py-2.5 font-semibold">المدة</th>
                          <th className="px-5 py-2.5 font-semibold">تعليمات</th>
                        </tr>
                      </thead>
                      <tbody>
                        {r.items.map((it, i) => (
                          <tr key={i} className="border-t border-line">
                            <td className="px-5 py-3 text-[13px] font-semibold text-navy-900">{it.drug}</td>
                            <td className="px-3 py-3 text-[12.5px] text-navy-600">{it.dose}</td>
                            <td className="px-3 py-3 text-[12.5px] text-navy-600">{it.freq}</td>
                            <td className="px-3 py-3 text-[12.5px] text-navy-600">{it.duration}</td>
                            <td className="px-5 py-3 text-[12.5px] text-navy-400">{it.note}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </Card>
              ))
            ) : (
              <Card><Empty icon={Pill} title="لا توجد وصفات لهذا المريض" body="أنشئ وصفة من صفحة الوصفات وسيظهر سجلها هنا." action={<Button variant="gold" onClick={() => nav('/prescriptions')}>إنشاء وصفة</Button>} /></Card>
            )}
          </div>
        )}

        {tab === 'labs' && (
          <Card>
            <CardHead title="الفحوصات والنتائج" sub="النتائج الحرجة معلّمة بالأحمر" icon={FlaskConical} action={<Button size="sm" variant="outline" icon={FlaskConical} onClick={() => nav('/labs')}>طلب فحص</Button>} />
            <div className="overflow-x-auto border-t border-line">
              {pLabs.length ? (
                <table className="w-full text-right">
                  <thead>
                    <tr className="bg-mist text-[11.5px] text-navy-400">
                      <th className="px-5 py-2.5 font-semibold">الفحص</th>
                      <th className="px-3 py-2.5 font-semibold">تاريخ الطلب</th>
                      <th className="px-3 py-2.5 font-semibold">النتيجة</th>
                      <th className="px-3 py-2.5 font-semibold">المدى الطبيعي</th>
                      <th className="px-5 py-2.5 font-semibold">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pLabs.map((l) => (
                      <tr key={l.id} className="border-t border-line hover:bg-mist">
                        <td className="px-5 py-3 text-[13px] font-semibold text-navy-900">{l.test}</td>
                        <td className="num px-3 py-3 text-[12.5px] text-navy-500">{l.ordered}</td>
                        <td className={`num px-3 py-3 text-[13px] font-semibold ${l.flag === 'حرج' || l.flag === 'مرتفع' || l.flag === 'منخفض' ? 'text-clay' : 'text-navy-700'}`}>{l.result}</td>
                        <td className="num px-3 py-3 text-[12.5px] text-navy-400">{l.range}</td>
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-2">
                            <Badge tone={statusTone(l.status)}>{l.status}</Badge>
                            {l.flag !== '—' && <Badge tone={statusTone(l.flag)}>{l.flag}</Badge>}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <Empty icon={FlaskConical} title="لا توجد فحوصات" body="اطلب فحصاً وسيظهر هنا مع النتيجة والمدى الطبيعي." />
              )}
            </div>
          </Card>
        )}

        {tab === 'files' && (
          <Card>
            <CardHead title="المرفقات" sub="تقارير وصور طبية مرفوعة على الملف" icon={Paperclip} />
            <div className="border-t border-line p-5">
              {pFiles.length ? (
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {pFiles.map((f) => (
                    <div key={f.id} className="group flex items-center gap-3 rounded-xl border border-line p-3.5 transition-colors hover:border-navy-200 hover:bg-mist">
                      <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-lg ${f.kind === 'pdf' ? 'bg-[#FCEEEE] text-clay' : 'bg-teal-50 text-teal-600'}`}>
                        {f.kind === 'pdf' ? <FileText size={17} /> : <Image size={17} />}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-semibold text-navy-900">{f.name}</p>
                        <p className="num text-[11.5px] text-navy-400">{f.size} · {f.date}</p>
                      </div>
                      <button className="grid h-8 w-8 place-items-center rounded-lg text-navy-300 opacity-0 transition-opacity hover:bg-white group-hover:opacity-100" aria-label="تنزيل">
                        <Download size={15} />
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <Empty icon={Paperclip} title="لا توجد مرفقات" body="ارفع تقرير مختبر أو صورة أشعة ليظهر ضمن ملف المريض." />
              )}
            </div>
          </Card>
        )}
      </div>

      {/* تحرير الملاحظات */}
      <Modal
        open={noteOpen}
        onClose={() => setNoteOpen(false)}
        title="ملاحظات الطبيب"
        sub="تظهر لك ولمن يملك صلاحية الملف الطبي فقط."
        footer={
          <>
            <Button variant="ghost" onClick={() => setNoteOpen(false)}>إلغاء</Button>
            <Button variant="gold" onClick={() => { setNoteOpen(false); toast('حُفظت الملاحظة على الملف') }}>حفظ الملاحظة</Button>
          </>
        }
      >
        <Textarea rows={8} defaultValue={p.doctorNotes} />
      </Modal>
    </>
  )
}

// ------------------------------------------------------------
// الخط الزمني للزيارات
// ------------------------------------------------------------
function Timeline({ visits, compact = false }) {
  const [open, setOpen] = useState(compact ? null : visits[0]?.id)

  if (!visits.length) return null

  return (
    <ol className="relative space-y-4 pe-6">
      {/* العمود الزمني */}
      <span className="absolute inset-y-1 right-[7px] w-px bg-line" />
      {visits.map((v) => {
        const on = open === v.id
        return (
          <li key={v.id} className="relative">
            <span className={`absolute -right-[23px] top-3 h-3.5 w-3.5 rounded-full border-2 border-white ${v.type === 'طارئ' ? 'bg-clay' : v.type === 'كشف أول' ? 'bg-gold-400' : 'bg-teal-500'}`} />
            <button
              onClick={() => setOpen(on ? null : v.id)}
              className={`w-full rounded-xl border px-4 py-3 text-right transition-colors ${on ? 'border-navy-200 bg-mist' : 'border-line hover:border-navy-200'}`}
            >
              <div className="flex flex-wrap items-center gap-2">
                <Badge tone={visitTypeTone[v.type]}>{v.type}</Badge>
                <span className="num text-[12.5px] font-semibold text-navy-900">{v.date}</span>
                <span className="num text-[11.5px] text-navy-300">{v.time}</span>
                <span className="num ms-auto text-[11.5px] text-navy-300">{v.id}</span>
              </div>
              <p className="mt-2 text-[13.5px] font-semibold leading-snug text-navy-900">{v.finalDx}</p>
              <p className="mt-0.5 text-[12.5px] text-navy-400">{v.complaint}</p>
            </button>

            {on && (
              <div className="mt-2 animate-rise space-y-4 rounded-xl border border-line bg-white p-4">
                <div className="flex flex-wrap gap-x-6 gap-y-2 rounded-lg bg-navy-950 px-4 py-2.5">
                  {[
                    ['ضغط', v.vitals.bp],
                    ['نبض', v.vitals.hr],
                    ['حرارة', v.vitals.temp],
                    ['أكسجين', `${v.vitals.spo2}%`],
                    ['سكر', v.vitals.sugar],
                  ].map(([k, val]) => (
                    <span key={k} className="text-[11px] text-navy-300/70">
                      {k} <b className="num ms-1 text-[13px] font-semibold text-teal-300">{val}</b>
                    </span>
                  ))}
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  {[
                    ['مدة الأعراض', v.duration],
                    ['الفحص السريري', v.exam],
                    ['التشخيص المبدئي', v.initialDx],
                    ['التشخيص النهائي', v.finalDx],
                    ['الخطة العلاجية', v.plan],
                    ['ملاحظات الطبيب', v.notes],
                  ].map(([k, val]) => (
                    <div key={k}>
                      <p className="eyebrow mb-1">{k}</p>
                      <p className="text-[13px] leading-relaxed text-navy-600">{val}</p>
                    </div>
                  ))}
                </div>

                <div className="flex flex-wrap items-center gap-2 border-t border-line pt-3.5">
                  <p className="eyebrow me-1">فحوصات مطلوبة</p>
                  {v.labs.map((l) => <Badge key={l} tone="slate">{l}</Badge>)}
                  <span className="num ms-auto text-[12px] font-semibold text-navy-500">{v.fee} {clinic.currency}</span>
                  <Button size="sm" variant="ghost" icon={Share2}>مشاركة التقرير</Button>
                </div>
              </div>
            )}
          </li>
        )
      })}
    </ol>
  )
}
