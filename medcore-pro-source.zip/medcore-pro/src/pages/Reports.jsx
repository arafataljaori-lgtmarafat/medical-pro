import { Link } from 'react-router-dom'
import { Users, Stethoscope, Wallet, UserPlus, Clock, CalendarClock, Download, ChevronLeft, TrendingUp } from 'lucide-react'
import { PageHeader } from '../components/Layout'
import { Avatar, Badge, BarChart, Button, Card, CardHead, Donut, useToast } from '../components/ui'
import { appointments, clinic, monthlyRevenue, monthlyVisits, reportStats, revenueSplit, topDiagnoses } from '../data/mockData'

const TODAY = '2026-07-17'

function Kpi({ label, value, unit, icon: Icon, hint, accent }) {
  return (
    <Card className={`p-5 ${accent ? 'border-gold-200 bg-gold-50/40' : ''}`}>
      <div className="flex items-start justify-between">
        <span className={`grid h-9 w-9 place-items-center rounded-lg ${accent ? 'bg-gold-400/20 text-gold-600' : 'bg-navy-50 text-navy-600'}`}>
          <Icon size={17} strokeWidth={1.8} />
        </span>
      </div>
      <p className="mt-4 text-[12px] font-medium text-navy-400">{label}</p>
      <p className="mt-1 flex items-baseline gap-1.5">
        <span className="num font-display text-[28px] font-extrabold leading-none text-navy-950">{value}</span>
        {unit && <span className="text-[12px] font-medium text-navy-400">{unit}</span>}
      </p>
      {hint && <p className="mt-2 text-[11.5px] text-navy-300">{hint}</p>}
    </Card>
  )
}

export default function Reports() {
  const toast = useToast()
  const upcoming = appointments.filter((a) => a.date > TODAY).sort((a, b) => a.date.localeCompare(b.date))
  const revTotal = revenueSplit.reduce((s, r) => s + r.value, 0)
  const maxDx = topDiagnoses[0].count

  return (
    <>
      <PageHeader
        eyebrow="يوليو 2026"
        title="التقارير"
        sub="صورة الشهر في العيادة: من زارك، بماذا شُخّص، وكم دخّلت."
        actions={<Button variant="outline" icon={Download} onClick={() => toast('يجري تجهيز التقرير الشهري')}>تنزيل التقرير</Button>}
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Kpi label="المرضى هذا الشهر" value={reportStats.patientsThisMonth} icon={Users} hint={`${reportStats.returningRate}% منهم مراجعون`} />
        <Kpi label="الزيارات" value={reportStats.visitsThisMonth} icon={Stethoscope} hint={`متوسط ${reportStats.avgVisitMinutes} دقيقة للزيارة`} />
        <Kpi label="مرضى جدد" value={reportStats.newPatients} icon={UserPlus} hint={`نسبة عدم الحضور ${reportStats.noShowRate}%`} />
        <Kpi label="الإيرادات" value={reportStats.revenueThisMonth.toLocaleString('en-US')} unit={clinic.currency} icon={Wallet} accent hint="مقارنة بـ 44,100 في يونيو" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHead title="الزيارات شهرياً" sub="عدد الزيارات المسجلة في كل شهر" icon={Stethoscope} action={<Badge tone="teal" dot>7 أشهر</Badge>} />
          <div className="border-t border-line p-5">
            <BarChart labels={monthlyVisits.labels} values={monthlyVisits.values} color="#0A2540" />
          </div>
        </Card>

        <Card>
          <CardHead title="الإيرادات شهرياً" sub={`بال${clinic.currency.replace('ر.س', 'ريال السعودي')}`} icon={Wallet} action={<Badge tone="gold" dot>+14% عن يناير</Badge>} />
          <div className="border-t border-line p-5">
            <BarChart labels={monthlyRevenue.labels} values={monthlyRevenue.values} color="#C9A227" format={(v) => (v / 1000).toFixed(1) + 'k'} />
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        {/* أكثر التشخيصات */}
        <Card className="lg:col-span-2">
          <CardHead title="أكثر التشخيصات" sub="ترتيب حسب عدد المرات خلال الشهر" icon={TrendingUp} />
          <div className="space-y-4 border-t border-line p-5">
            {topDiagnoses.map((d, i) => (
              <div key={d.name}>
                <div className="mb-1.5 flex items-center gap-3">
                  <span className="num text-[11px] font-bold text-navy-200">{String(i + 1).padStart(2, '0')}</span>
                  <span className="text-[13px] font-semibold text-navy-800">{d.name}</span>
                  <span className="num ms-auto text-[12.5px] font-bold text-navy-900">{d.count}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-navy-50">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${(d.count / maxDx) * 100}%`, background: i === 0 ? '#C9A227' : '#12A5A5' }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* توزيع الإيراد */}
        <Card>
          <CardHead title="مصادر الإيراد" sub="هذا الشهر" icon={Wallet} />
          <div className="border-t border-line p-5">
            <div className="relative mx-auto w-fit">
              <Donut data={revenueSplit} />
              <div className="absolute inset-0 grid place-items-center">
                <div className="text-center">
                  <p className="num font-display text-[19px] font-extrabold text-navy-950">{(revTotal / 1000).toFixed(1)}k</p>
                  <p className="text-[10px] text-navy-300">{clinic.currency}</p>
                </div>
              </div>
            </div>
            <div className="mt-5 space-y-2.5">
              {revenueSplit.map((r) => (
                <div key={r.label} className="flex items-center gap-2.5">
                  <i className="h-2.5 w-2.5 rounded-sm" style={{ background: r.color }} />
                  <span className="text-[12.5px] text-navy-600">{r.label}</span>
                  <span className="num ms-auto text-[12.5px] font-semibold text-navy-900">{r.value.toLocaleString('en-US')}</span>
                  <span className="num w-9 text-left text-[11px] text-navy-300">{Math.round((r.value / revTotal) * 100)}%</span>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* المراجعات القادمة */}
      <Card className="mt-4">
        <CardHead
          title="المراجعات القادمة"
          sub={`${upcoming.length} مراجعة محجوزة بعد اليوم`}
          icon={CalendarClock}
          action={
            <Link to="/appointments" className="flex items-center gap-1 text-[12.5px] font-semibold text-teal-600 hover:text-teal-700">
              التقويم <ChevronLeft size={14} />
            </Link>
          }
        />
        <div className="grid gap-px border-t border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
          {upcoming.map((a) => (
            <Link key={a.id} to={`/patients/${a.patientId}`} className="flex items-center gap-3 bg-white p-4 hover:bg-mist">
              <Avatar initials={a.initials} size="sm" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-semibold text-navy-900">{a.name}</p>
                <p className="text-[11.5px] text-navy-400">{a.type}</p>
              </div>
              <div className="text-left">
                <p className="num text-[12.5px] font-semibold text-navy-900">{a.date}</p>
                <p className="num flex items-center justify-end gap-1 text-[11px] text-navy-300"><Clock size={10} />{a.time}</p>
              </div>
            </Link>
          ))}
        </div>
      </Card>
    </>
  )
}
