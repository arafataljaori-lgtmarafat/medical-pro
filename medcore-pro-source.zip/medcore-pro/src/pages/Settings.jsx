import { useState } from 'react'
import { UserCog, Building2, Wallet, Users, FileText, Palette, Check, Save, Plus, ShieldCheck, Upload } from 'lucide-react'
import { PageHeader } from '../components/Layout'
import { Avatar, Badge, Button, Card, CardHead, Field, Input, Select, Textarea, useToast } from '../components/ui'
import { clinic, currentUser, roles, team } from '../data/mockData'

const TABS = [
  { key: 'doctor', label: 'بيانات الطبيب', icon: UserCog },
  { key: 'clinic', label: 'العيادة والرسوم', icon: Building2 },
  { key: 'users', label: 'المستخدمون والصلاحيات', icon: Users },
  { key: 'rx', label: 'تخصيص الوصفة', icon: FileText },
  { key: 'brand', label: 'الشعار والألوان', icon: Palette },
]

const palettes = [
  { name: 'كحلي وتركواز', colors: ['#0A2540', '#12A5A5', '#C9A227'], key: 'default' },
  { name: 'أخضر طبي', colors: ['#0E3B2E', '#2E9E6B', '#C9A227'], key: 'green' },
  { name: 'أزرق بارد', colors: ['#12304F', '#3B82C4', '#94A3B8'], key: 'blue' },
  { name: 'رمادي رصين', colors: ['#1F2933', '#5C7080', '#B08D1E'], key: 'slate' },
]

export default function Settings() {
  const toast = useToast()
  const [tab, setTab] = useState('doctor')
  const [palette, setPalette] = useState('default')

  return (
    <>
      <PageHeader
        eyebrow="الإدارة"
        title="الإعدادات"
        sub="بيانات العيادة والرسوم والصلاحيات وشكل الوصفة المطبوعة."
        actions={<Button variant="gold" icon={Save} onClick={() => toast('حُفظت التغييرات')}>حفظ التغييرات</Button>}
      />

      <div className="grid gap-4 lg:grid-cols-[240px_1fr]">
        {/* التبويبات */}
        <nav className="flex gap-1 overflow-x-auto lg:block lg:space-y-1 lg:overflow-visible">
          {TABS.map((t) => {
            const on = tab === t.key
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`flex shrink-0 items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-[13px] transition-colors lg:w-full ${
                  on ? 'bg-navy-950 font-semibold text-white' : 'border border-line bg-white text-navy-600 hover:bg-mist lg:border-0 lg:bg-transparent'
                }`}
              >
                <t.icon size={15} className={on ? 'text-teal-300' : 'text-navy-300'} />
                {t.label}
              </button>
            )
          })}
        </nav>

        <div key={tab} className="animate-rise space-y-4">
          {tab === 'doctor' && (
            <Card>
              <CardHead title="بيانات الطبيب" sub="تظهر في الوصفات والتقارير المطبوعة" icon={UserCog} />
              <div className="border-t border-line p-5">
                <div className="mb-6 flex items-center gap-4">
                  <Avatar initials={currentUser.initials} size="lg" ring />
                  <div>
                    <Button size="sm" variant="outline" icon={Upload}>تغيير الصورة</Button>
                    <p className="mt-1.5 text-[11.5px] text-navy-300">PNG أو JPG بحد أقصى 2 ميغابايت.</p>
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="الاسم الكامل" required><Input defaultValue={currentUser.name} /></Field>
                  <Field label="المسمى الطبي" required><Input defaultValue={currentUser.specialty} /></Field>
                  <Field label="رقم التصنيف المهني"><Input defaultValue="SCFHS-88214" dir="ltr" className="text-right" /></Field>
                  <Field label="سنوات الخبرة"><Input defaultValue="14" dir="ltr" className="text-right" /></Field>
                  <Field label="البريد الإلكتروني"><Input defaultValue={currentUser.email} dir="ltr" className="text-right" /></Field>
                  <Field label="رقم الجوال"><Input defaultValue={currentUser.phone} dir="ltr" className="text-right" /></Field>
                  <Field label="نبذة تظهر للمرضى" className="sm:col-span-2">
                    <Textarea rows={3} defaultValue="استشاري باطنية وقلب، مهتم بضبط السكري والضغط وأمراض الشرايين التاجية." />
                  </Field>
                </div>
              </div>
            </Card>
          )}

          {tab === 'clinic' && (
            <>
              <Card>
                <CardHead title="بيانات العيادة" sub="تُطبع في ترويسة الوصفة والتقارير" icon={Building2} />
                <div className="grid gap-4 border-t border-line p-5 sm:grid-cols-2">
                  <Field label="اسم العيادة" required><Input defaultValue={clinic.name} /></Field>
                  <Field label="التخصص" required><Input defaultValue={clinic.specialty} /></Field>
                  <Field label="رقم الترخيص"><Input defaultValue={clinic.license} dir="ltr" className="text-right" /></Field>
                  <Field label="هاتف العيادة"><Input defaultValue={clinic.phone} dir="ltr" className="text-right" /></Field>
                  <Field label="العنوان" className="sm:col-span-2"><Input defaultValue={clinic.address} /></Field>
                  <Field label="ساعات العمل" className="sm:col-span-2" hint="تظهر للمرضى عند الحجز">
                    <Input defaultValue="الأحد — الخميس · 09:00 صباحاً إلى 05:00 مساءً" />
                  </Field>
                </div>
              </Card>

              <Card>
                <CardHead title="رسوم الكشف" sub="تُحتسب تلقائياً عند تسجيل الزيارة" icon={Wallet} />
                <div className="grid gap-4 border-t border-line p-5 sm:grid-cols-3">
                  <Field label={`كشف أول (${clinic.currency})`}><Input defaultValue={clinic.fee} dir="ltr" className="text-right" /></Field>
                  <Field label={`متابعة (${clinic.currency})`} hint="خلال 14 يوماً من الكشف الأول"><Input defaultValue={clinic.followUpFee} dir="ltr" className="text-right" /></Field>
                  <Field label={`تقرير طبي (${clinic.currency})`}><Input defaultValue="80" dir="ltr" className="text-right" /></Field>
                  <Field label="مدة صلاحية المتابعة" className="sm:col-span-3">
                    <Select defaultValue="14 يوماً">
                      {['7 أيام', '14 يوماً', '21 يوماً', '30 يوماً'].map((d) => <option key={d}>{d}</option>)}
                    </Select>
                  </Field>
                </div>
              </Card>
            </>
          )}

          {tab === 'users' && (
            <>
              <Card>
                <CardHead
                  title="المستخدمون"
                  sub={`${team.length} مستخدمين في هذه العيادة`}
                  icon={Users}
                  action={<Button size="sm" variant="outline" icon={Plus} onClick={() => toast('أُرسلت دعوة الانضمام')}>دعوة مستخدم</Button>}
                />
                <div className="border-t border-line">
                  {team.map((u) => (
                    <div key={u.id} className="flex items-center gap-3 border-b border-line px-5 py-3.5 last:border-0 hover:bg-mist">
                      <Avatar initials={u.initials} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="text-[13.5px] font-semibold text-navy-900">{u.name}</p>
                        <p className="text-[11.5px] text-navy-400">{u.role} · آخر ظهور {u.lastSeen}</p>
                      </div>
                      <Badge tone={u.status === 'نشط' ? 'green' : 'slate'} dot>{u.status}</Badge>
                      <Button size="sm" variant="ghost">تعديل</Button>
                    </div>
                  ))}
                </div>
              </Card>

              <Card>
                <CardHead title="الصلاحيات" sub="ما يستطيع كل دور رؤيته والتعديل عليه" icon={ShieldCheck} />
                <div className="grid gap-px border-t border-line bg-line sm:grid-cols-2">
                  {roles.map((r) => (
                    <div key={r.key} className="bg-white p-5">
                      <p className="text-[13.5px] font-bold text-navy-900">{r.label}</p>
                      <p className="mt-1 text-[12.5px] leading-relaxed text-navy-400">{r.desc}</p>
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {r.permissions.map((pm) => <Badge key={pm} tone="slate">{pm}</Badge>)}
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </>
          )}

          {tab === 'rx' && (
            <Card>
              <CardHead title="تخصيص الوصفة" sub="ما يظهر في الورقة المطبوعة" icon={FileText} />
              <div className="border-t border-line p-5">
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="مقاس الورقة">
                    <Select defaultValue="A5">
                      {['A4', 'A5', 'نصف A4'].map((s) => <option key={s}>{s}</option>)}
                    </Select>
                  </Field>
                  <Field label="اللغة">
                    <Select defaultValue="عربي">
                      <option>عربي</option>
                      <option>عربي وإنجليزي</option>
                      <option>إنجليزي</option>
                    </Select>
                  </Field>
                  <Field label="نص أسفل الوصفة" className="sm:col-span-2" hint="يظهر تحت التوقيع في كل وصفة">
                    <Textarea rows={2} defaultValue="لا تُصرف هذه الوصفة أكثر من مرة واحدة. للاستفسار اتصل بالعيادة." />
                  </Field>
                </div>

                <div className="mt-6 space-y-2.5">
                  <p className="eyebrow mb-3">عناصر تظهر في الوصفة</p>
                  {[
                    ['ترويسة العيادة والشعار', true],
                    ['رقم الترخيص', true],
                    ['التشخيص', true],
                    ['تنبيه الحساسية', true],
                    ['رمز التحقق (QR)', true],
                    ['وزن المريض وطوله', false],
                    ['سعر تقديري للأدوية', false],
                  ].map(([label, on]) => (
                    <Toggle key={label} label={label} defaultOn={on} />
                  ))}
                </div>
              </div>
            </Card>
          )}

          {tab === 'brand' && (
            <>
              <Card>
                <CardHead title="الشعار" sub="يظهر في الترويسة والوصفات" icon={Palette} />
                <div className="flex flex-wrap items-center gap-5 border-t border-line p-5">
                  <div className="grid h-20 w-20 place-items-center rounded-xl border border-dashed border-line bg-mist text-navy-300">
                    <Upload size={20} />
                  </div>
                  <div>
                    <Button size="sm" variant="outline" icon={Upload}>رفع الشعار</Button>
                    <p className="mt-1.5 text-[11.5px] text-navy-300">SVG أو PNG بخلفية شفافة، 512×512 بكسل على الأقل.</p>
                  </div>
                </div>
              </Card>

              <Card>
                <CardHead title="لوحة الألوان" sub="تُطبق على الواجهة والمطبوعات" icon={Palette} />
                <div className="grid gap-3 border-t border-line p-5 sm:grid-cols-2">
                  {palettes.map((pl) => {
                    const on = palette === pl.key
                    return (
                      <button
                        key={pl.key}
                        onClick={() => setPalette(pl.key)}
                        className={`flex items-center gap-3 rounded-xl border p-4 text-right transition-colors ${
                          on ? 'border-navy-900 bg-mist' : 'border-line hover:border-navy-200'
                        }`}
                      >
                        <span className="flex gap-1.5">
                          {pl.colors.map((c) => <i key={c} className="h-7 w-7 rounded-md" style={{ background: c }} />)}
                        </span>
                        <span className="text-[13px] font-semibold text-navy-800">{pl.name}</span>
                        {on && <Check size={16} className="ms-auto text-teal-500" />}
                      </button>
                    )
                  })}
                </div>
              </Card>
            </>
          )}
        </div>
      </div>
    </>
  )
}

function Toggle({ label, defaultOn }) {
  const [on, setOn] = useState(defaultOn)
  return (
    <button onClick={() => setOn(!on)} className="flex w-full items-center justify-between rounded-xl border border-line px-4 py-3 hover:bg-mist">
      <span className="text-[13px] text-navy-700">{label}</span>
      <span className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${on ? 'bg-teal-500' : 'bg-navy-100'}`}>
        <span className="absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all" style={{ right: on ? 2 : 18 }} />
      </span>
    </button>
  )
}
