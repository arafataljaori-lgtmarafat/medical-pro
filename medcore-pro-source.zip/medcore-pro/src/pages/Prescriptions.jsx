import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Pill, Plus, Printer, Share2, Trash2, FileText, Search, Activity, ShieldAlert } from 'lucide-react'
import { PageHeader } from '../components/Layout'
import { Badge, Button, Card, CardHead, Empty, Field, Input, Select, Textarea, useToast } from '../components/ui'
import { clinic, currentUser, drugCatalog, durations, frequencies, patients, prescriptions, routes } from '../data/mockData'

const rxStatusTone = { 'مصروفة': 'green', 'بانتظار الصرف': 'gold', 'مسودة': 'slate' }

export default function Prescriptions() {
  const nav = useNavigate()
  const toast = useToast()
  const [pid, setPid] = useState('P-1042')
  const [dx, setDx] = useState('سكري نوع 2 مع اعتلال أعصاب طرفي')
  const [q, setQ] = useState('')
  const [items, setItems] = useState([
    { drug: 'ميتفورمين 1000 ملغ', route: 'فموي', dose: 'قرص واحد', freq: 'مرتان يومياً', duration: 'مستمر', note: 'بعد الأكل مباشرة' },
    { drug: 'بريغابالين 75 ملغ', route: 'فموي', dose: 'كبسولة واحدة', freq: 'مرة يومياً', duration: '14 يوماً', note: 'قبل النوم — قد يسبب نعاساً' },
  ])

  const p = patients.find((x) => x.id === pid)
  const hasAllergy = p && !p.allergies[0]?.includes('لا توجد')
  const catalog = q.trim() ? drugCatalog.filter((d) => d.name.includes(q) || d.class.includes(q)) : drugCatalog

  const addDrug = (d) => {
    setItems((s) => [
      ...s,
      { drug: `${d.name} ${d.strengths[0]}`, route: 'فموي', dose: `${d.form} واحد`, freq: 'مرة يومياً', duration: '7 أيام', note: '' },
    ])
    setQ('')
  }
  const update = (i, k, v) => setItems((s) => s.map((it, j) => (j === i ? { ...it, [k]: v } : it)))
  const remove = (i) => setItems((s) => s.filter((_, j) => j !== i))

  return (
    <>
      <PageHeader
        eyebrow="العلاج"
        title="الوصفات"
        sub="ابنِ الوصفة على اليمين وتابع معاينتها على اليسار كما ستُطبع تماماً."
        actions={
          <>
            <Button variant="outline" icon={Share2} onClick={() => toast('نُسخ رابط الوصفة')}>مشاركة</Button>
            <Button variant="gold" icon={Printer} onClick={() => toast('أُرسلت الوصفة للطباعة', 'gold')}>طباعة PDF</Button>
          </>
        }
      />

      <div className="grid gap-4 xl:grid-cols-[1fr_460px]">
        {/* ===== المنشئ ===== */}
        <div className="space-y-4">
          <Card>
            <CardHead title="بيانات الوصفة" icon={FileText} />
            <div className="grid gap-4 border-t border-line p-5 sm:grid-cols-2">
              <Field label="المريض" required>
                <Select value={pid} onChange={(e) => setPid(e.target.value)}>
                  {patients.map((x) => <option key={x.id} value={x.id}>{x.name} — {x.id}</option>)}
                </Select>
              </Field>
              <Field label="التشخيص" required>
                <Input value={dx} onChange={(e) => setDx(e.target.value)} />
              </Field>
            </div>

            {hasAllergy && (
              <div className="mx-5 mb-5 flex items-start gap-2.5 rounded-xl border border-[#F0D2D3] bg-[#FDF4F4] p-3.5">
                <ShieldAlert size={15} className="mt-0.5 shrink-0 text-clay" />
                <div>
                  <p className="text-[12.5px] font-bold text-clay">تحقق قبل الصرف — حساسية مسجّلة</p>
                  <p className="mt-0.5 text-[12.5px] leading-relaxed text-navy-600">{p.allergies.join(' · ')}</p>
                </div>
              </div>
            )}
          </Card>

          {/* قائمة الأدوية */}
          <Card>
            <CardHead
              title="قائمة الأدوية"
              sub="ابحث ثم اضغط الدواء لإضافته إلى الوصفة"
              icon={Pill}
              action={<Badge tone="teal">{items.length} دواء</Badge>}
            />
            <div className="border-t border-line p-5">
              <div className="relative mb-4">
                <Search size={16} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-navy-300" />
                <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث بالاسم أو التصنيف الدوائي" className="pe-10" />
              </div>

              <div className="mb-6 flex max-h-40 flex-wrap gap-2 overflow-y-auto">
                {catalog.map((d) => (
                  <button
                    key={d.id}
                    onClick={() => addDrug(d)}
                    className="group flex items-center gap-2 rounded-lg border border-line bg-white px-3 py-1.5 text-right transition-colors hover:border-teal-400 hover:bg-teal-50"
                  >
                    <Plus size={12} className="text-navy-300 group-hover:text-teal-600" />
                    <span className="text-[12.5px] font-medium text-navy-700">{d.name}</span>
                    <span className="text-[10.5px] text-navy-300">{d.class}</span>
                  </button>
                ))}
                {catalog.length === 0 && <p className="py-3 text-[12.5px] text-navy-300">لا يوجد دواء بهذا الاسم في القائمة.</p>}
              </div>

              {items.length === 0 ? (
                <Empty icon={Pill} title="الوصفة فارغة" body="اختر دواءً من القائمة أعلاه ليظهر هنا بجرعته وتعليماته." />
              ) : (
                <div className="space-y-3">
                  {items.map((it, i) => (
                    <div key={i} className="rounded-xl border border-line p-4">
                      <div className="mb-3 flex items-center gap-2">
                        <span className="num grid h-6 w-6 place-items-center rounded-md bg-navy-950 text-[11px] font-bold text-teal-300">{i + 1}</span>
                        <input
                          value={it.drug}
                          onChange={(e) => update(i, 'drug', e.target.value)}
                          className="min-w-0 flex-1 border-0 bg-transparent p-0 text-[14px] font-bold text-navy-900 focus:outline-none focus:ring-0"
                        />
                        <button onClick={() => remove(i)} className="grid h-7 w-7 place-items-center rounded-lg text-navy-300 hover:bg-[#FCEEEE] hover:text-clay" aria-label="حذف الدواء">
                          <Trash2 size={14} />
                        </button>
                      </div>
                      <div className="grid gap-3 sm:grid-cols-4">
                        <Field label="الطريق">
                          <Select value={it.route} onChange={(e) => update(i, 'route', e.target.value)}>
                            {routes.map((r) => <option key={r}>{r}</option>)}
                          </Select>
                        </Field>
                        <Field label="الجرعة">
                          <Input value={it.dose} onChange={(e) => update(i, 'dose', e.target.value)} />
                        </Field>
                        <Field label="عدد المرات">
                          <Select value={it.freq} onChange={(e) => update(i, 'freq', e.target.value)}>
                            {frequencies.map((f) => <option key={f}>{f}</option>)}
                          </Select>
                        </Field>
                        <Field label="مدة الاستخدام">
                          <Select value={it.duration} onChange={(e) => update(i, 'duration', e.target.value)}>
                            {durations.map((d) => <option key={d}>{d}</option>)}
                          </Select>
                        </Field>
                      </div>
                      <Field label="تعليمات للمريض" className="mt-3">
                        <Textarea rows={2} value={it.note} onChange={(e) => update(i, 'note', e.target.value)} placeholder="مثال: يؤخذ بعد الأكل مباشرة مع كوب ماء" />
                      </Field>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Card>

          {/* سجل الوصفات */}
          <Card>
            <CardHead title="وصفات سابقة" sub="آخر الوصفات المصروفة في العيادة" icon={Activity} />
            <div className="border-t border-line">
              {prescriptions.map((r) => (
                <div key={r.id} className="flex flex-wrap items-center gap-3 border-b border-line px-5 py-3.5 last:border-0 hover:bg-mist">
                  <span className="num w-20 shrink-0 text-[12px] font-semibold text-navy-300">{r.id}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13.5px] font-semibold text-navy-900">{r.patientName}</p>
                    <p className="truncate text-[12px] text-navy-400">{r.diagnosis}</p>
                  </div>
                  <span className="num text-[12px] text-navy-400">{r.items.length} أدوية</span>
                  <span className="num text-[12px] text-navy-400">{r.date}</span>
                  <Badge tone={rxStatusTone[r.status]}>{r.status}</Badge>
                  <Button size="sm" variant="ghost" onClick={() => nav(`/patients/${r.patientId}`)}>الملف</Button>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* ===== المعاينة ===== */}
        <div>
          <div className="sticky top-24">
            <div className="mb-3 flex items-center justify-between">
              <p className="eyebrow">معاينة الطباعة</p>
              <Badge tone="slate">A5 · عمودي</Badge>
            </div>

            <div className="overflow-hidden rounded-2xl border border-line bg-white shadow-lift">
              {/* ترويسة */}
              <div className="relative overflow-hidden bg-navy-950 grid-texture px-6 py-5">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-display text-[16px] font-extrabold text-white">{clinic.name}</p>
                    <p className="mt-0.5 text-[11px] text-navy-300/80">{clinic.specialty}</p>
                  </div>
                  <span className="grid h-10 w-10 place-items-center rounded-lg border border-gold-400/40 bg-gold-400/10">
                    <span className="font-display text-[16px] font-extrabold text-gold-300">℞</span>
                  </span>
                </div>
                <div className="mt-4 flex flex-wrap gap-x-4 gap-y-1 border-t border-white/[0.08] pt-3 text-[10.5px] text-navy-300/70">
                  <span className="num">{clinic.phone}</span>
                  <span>{clinic.address}</span>
                  <span className="num">ترخيص {clinic.license}</span>
                </div>
              </div>

              {/* بيانات المريض */}
              <div className="grid grid-cols-2 gap-y-2.5 border-b border-dashed border-line px-6 py-4">
                {[
                  ['المريض', p?.name],
                  ['رقم الملف', p?.id],
                  ['العمر والجنس', `${p?.age} سنة · ${p?.gender}`],
                  ['التاريخ', '2026-07-17'],
                ].map(([k, v]) => (
                  <div key={k}>
                    <p className="text-[9.5px] font-semibold tracking-wider text-navy-300">{k}</p>
                    <p className="num mt-0.5 text-[12.5px] font-semibold text-navy-900">{v}</p>
                  </div>
                ))}
                <div className="col-span-2">
                  <p className="text-[9.5px] font-semibold tracking-wider text-navy-300">التشخيص</p>
                  <p className="mt-0.5 text-[12.5px] font-semibold text-navy-900">{dx}</p>
                </div>
                {hasAllergy && (
                  <div className="col-span-2 rounded-lg border border-[#F0D2D3] bg-[#FDF4F4] px-2.5 py-1.5">
                    <p className="text-[10.5px] font-bold text-clay">حساسية: {p.allergies.join(' · ')}</p>
                  </div>
                )}
              </div>

              {/* الأدوية */}
              <div className="px-6 py-4">
                {items.length === 0 ? (
                  <p className="py-10 text-center text-[12.5px] text-navy-300">لم يُضف أي دواء بعد.</p>
                ) : (
                  <ol className="space-y-3.5">
                    {items.map((it, i) => (
                      <li key={i} className="flex gap-3">
                        <span className="num mt-0.5 text-[11px] font-bold text-gold-400">{String(i + 1).padStart(2, '0')}</span>
                        <div className="min-w-0 flex-1 border-b border-dashed border-line pb-3.5">
                          <p className="text-[13.5px] font-bold text-navy-950">{it.drug}</p>
                          <p className="mt-0.5 text-[12px] text-navy-600">
                            {it.dose} · {it.freq} · لمدة {it.duration} · {it.route}
                          </p>
                          {it.note && <p className="mt-1 text-[11.5px] italic text-navy-400">{it.note}</p>}
                        </div>
                      </li>
                    ))}
                  </ol>
                )}
              </div>

              {/* التوقيع */}
              <div className="flex items-end justify-between border-t border-line bg-mist px-6 py-4">
                <div>
                  <p className="text-[9.5px] font-semibold tracking-wider text-navy-300">الطبيب المعالج</p>
                  <p className="mt-1 font-display text-[13.5px] font-bold text-navy-950">{currentUser.name}</p>
                  <p className="text-[10.5px] text-navy-400">{currentUser.specialty}</p>
                </div>
                <div className="grid h-14 w-14 place-items-center rounded-md border border-line bg-white">
                  <div className="grid h-9 w-9 grid-cols-4 gap-px">
                    {Array.from({ length: 16 }).map((_, i) => (
                      <span key={i} className={`${[0, 1, 2, 4, 6, 8, 9, 11, 13, 15].includes(i) ? 'bg-navy-900' : 'bg-transparent'}`} />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-3 flex gap-2">
              <Button variant="outline" icon={Share2} onClick={() => toast('نُسخ رابط الوصفة')} className="flex-1">مشاركة</Button>
              <Button variant="gold" icon={Printer} onClick={() => toast('أُرسلت الوصفة للطباعة', 'gold')} className="flex-1">طباعة PDF</Button>
            </div>
            <p className="mt-2 text-center text-[11px] text-navy-300">المعاينة تعكس ما ستراه في الملف المطبوع.</p>
          </div>
        </div>
      </div>
    </>
  )
}
