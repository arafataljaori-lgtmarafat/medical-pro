import { useMemo, useState } from 'react'
import { useNavigate, useOutletContext } from 'react-router-dom'
import { Search, Plus, SlidersHorizontal, FolderOpen, Phone, Users, X } from 'lucide-react'
import { PageHeader } from '../components/Layout'
import { Avatar, Badge, Button, Card, Empty, Input, Select, statusTone } from '../components/ui'
import { patients } from '../data/mockData'

const statuses = ['الكل', 'جديد', 'متابعة', 'حالة نشطة', 'حرج', 'مكتمل']
const risks = ['كل المستويات', 'مرتفع', 'متوسط', 'منخفض']
const recency = [
  { key: 'any', label: 'أي وقت' },
  { key: '7', label: 'آخر 7 أيام' },
  { key: '30', label: 'آخر 30 يوماً' },
  { key: '90', label: 'أكثر من 90 يوماً' },
]

const TODAY = new Date('2026-07-17')
const daysSince = (d) => Math.round((TODAY - new Date(d)) / 86400000)

export default function Patients() {
  const nav = useNavigate()
  const { openNewPatient } = useOutletContext()
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('الكل')
  const [risk, setRisk] = useState('كل المستويات')
  const [since, setSince] = useState('any')

  const rows = useMemo(
    () =>
      patients.filter((p) => {
        if (q.trim() && !(p.name.includes(q) || p.phone.includes(q) || p.id.toLowerCase().includes(q.toLowerCase()))) return false
        if (status !== 'الكل' && p.status !== status) return false
        if (risk !== 'كل المستويات' && p.risk !== risk) return false
        const d = daysSince(p.lastVisit)
        if (since === '7' && d > 7) return false
        if (since === '30' && d > 30) return false
        if (since === '90' && d <= 90) return false
        return true
      }),
    [q, status, risk, since]
  )

  const dirty = q || status !== 'الكل' || risk !== 'كل المستويات' || since !== 'any'
  const reset = () => {
    setQ('')
    setStatus('الكل')
    setRisk('كل المستويات')
    setSince('any')
  }

  return (
    <>
      <PageHeader
        eyebrow="السجل"
        title="المرضى"
        sub={`${patients.length} ملفاً مسجلاً في ${'عيادة النخبة التخصصية'}. اضغط أي صف لفتح الملف الكامل.`}
        actions={<Button variant="gold" icon={Plus} onClick={openNewPatient}>مريض جديد</Button>}
      />

      {/* الفلاتر */}
      <Card className="mb-4 p-4">
        <div className="grid gap-3 md:grid-cols-[1fr_auto_auto_auto_auto]">
          <div className="relative">
            <Search size={16} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-navy-300" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث سريع بالاسم أو الجوال أو رقم الملف" className="ps-3.5 pe-10" />
          </div>
          <Select value={status} onChange={(e) => setStatus(e.target.value)} className="md:w-40">
            {statuses.map((s) => <option key={s}>{s}</option>)}
          </Select>
          <Select value={risk} onChange={(e) => setRisk(e.target.value)} className="md:w-40">
            {risks.map((s) => <option key={s}>{s}</option>)}
          </Select>
          <Select value={since} onChange={(e) => setSince(e.target.value)} className="md:w-40">
            {recency.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
          </Select>
          {dirty ? (
            <Button variant="ghost" icon={X} onClick={reset}>مسح الفلاتر</Button>
          ) : (
            <span className="hidden items-center gap-1.5 px-2 text-[12px] text-navy-300 md:flex">
              <SlidersHorizontal size={14} /> بلا فلاتر
            </span>
          )}
        </div>
      </Card>

      <Card className="overflow-hidden">
        <div className="flex items-center justify-between border-b border-line px-5 py-3.5">
          <p className="text-[13px] text-navy-500">
            <span className="num font-bold text-navy-900">{rows.length}</span> من {patients.length} مريضاً
          </p>
          <Badge tone="slate">مرتبة حسب آخر زيارة</Badge>
        </div>

        {rows.length === 0 ? (
          <Empty
            icon={Users}
            title="لا يوجد مريض بهذه الفلاتر"
            body="جرّب توسيع نطاق آخر زيارة أو مسح الفلاتر، أو سجّل مريضاً جديداً."
            action={<Button variant="outline" onClick={reset}>مسح الفلاتر</Button>}
          />
        ) : (
          <>
            {/* جدول — سطح المكتب */}
            <div className="hidden overflow-x-auto lg:block">
              <table className="w-full text-right">
                <thead>
                  <tr className="border-b border-line bg-mist text-[11.5px] font-semibold text-navy-400">
                    <th className="px-5 py-3 font-semibold">المريض</th>
                    <th className="px-3 py-3 font-semibold">العمر</th>
                    <th className="px-3 py-3 font-semibold">رقم الهاتف</th>
                    <th className="px-3 py-3 font-semibold">آخر زيارة</th>
                    <th className="px-3 py-3 font-semibold">الحالة</th>
                    <th className="px-3 py-3 font-semibold">الخطورة</th>
                    <th className="px-5 py-3 font-semibold">الملف</th>
                  </tr>
                </thead>
                <tbody>
                  {[...rows]
                    .sort((a, b) => new Date(b.lastVisit) - new Date(a.lastVisit))
                    .map((p) => (
                      <tr
                        key={p.id}
                        onClick={() => nav(`/patients/${p.id}`)}
                        className="cursor-pointer border-b border-line transition-colors last:border-0 hover:bg-mist"
                      >
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-3">
                            <Avatar initials={p.initials} size="sm" ring={p.risk === 'مرتفع'} />
                            <div>
                              <p className="text-[13.5px] font-semibold text-navy-900">{p.name}</p>
                              <p className="num text-[11.5px] text-navy-400">{p.id} · {p.gender}</p>
                            </div>
                          </div>
                        </td>
                        <td className="num px-3 py-3 text-[13px] text-navy-600">{p.age}</td>
                        <td className="num px-3 py-3 text-[13px] text-navy-600">{p.phone}</td>
                        <td className="px-3 py-3">
                          <span className="num text-[13px] text-navy-600">{p.lastVisit}</span>
                          <span className="block text-[11px] text-navy-300">قبل {daysSince(p.lastVisit)} يوماً</span>
                        </td>
                        <td className="px-3 py-3"><Badge tone={statusTone(p.status)}>{p.status}</Badge></td>
                        <td className="px-3 py-3"><Badge tone={statusTone(p.risk)}>{p.risk}</Badge></td>
                        <td className="px-5 py-3">
                          <Button size="sm" variant="outline" icon={FolderOpen}>فتح</Button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>

            {/* بطاقات — الجوال */}
            <div className="divide-y divide-line lg:hidden">
              {rows.map((p) => (
                <button key={p.id} onClick={() => nav(`/patients/${p.id}`)} className="block w-full px-4 py-4 text-right hover:bg-mist">
                  <div className="flex items-center gap-3">
                    <Avatar initials={p.initials} ring={p.risk === 'مرتفع'} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[14px] font-bold text-navy-900">{p.name}</p>
                      <p className="num text-[12px] text-navy-400">{p.age} سنة · {p.gender} · {p.id}</p>
                    </div>
                    <Badge tone={statusTone(p.status)}>{p.status}</Badge>
                  </div>
                  <div className="mt-3 flex items-center justify-between border-t border-line pt-3 text-[12px] text-navy-400">
                    <span className="num flex items-center gap-1.5"><Phone size={12} />{p.phone}</span>
                    <span className="num">آخر زيارة {p.lastVisit}</span>
                  </div>
                </button>
              ))}
            </div>
          </>
        )}
      </Card>
    </>
  )
}
