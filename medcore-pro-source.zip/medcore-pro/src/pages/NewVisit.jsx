import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Stethoscope, Gauge, HeartPulse, Thermometer, Wind, Scale, Droplet,
  ClipboardList, FlaskConical, CalendarPlus, NotebookPen, Check, Save, ChevronRight,
} from 'lucide-react'
import { PageHeader } from '../components/Layout'
import { Avatar, Badge, Button, Card, CardHead, Field, Input, Select, Textarea, useToast } from '../components/ui'
import { labCatalog, patients, waitingList } from '../data/mockData'

const sections = [
  { key: 'who', label: 'المريض', icon: Stethoscope },
  { key: 'complaint', label: 'الشكوى', icon: ClipboardList },
  { key: 'vitals', label: 'العلامات الحيوية', icon: HeartPulse },
  { key: 'exam', label: 'الفحص والتشخيص', icon: NotebookPen },
  { key: 'plan', label: 'الخطة والمتابعة', icon: CalendarPlus },
]

function Section({ id, n, title, sub, icon: Icon, children }) {
  return (
    <Card id={id} className="scroll-mt-24">
      <CardHead
        title={title}
        sub={sub}
        icon={Icon}
        action={<span className="num text-[11px] font-semibold text-navy-200">{String(n).padStart(2, '0')}</span>}
      />
      <div className="border-t border-line p-5">{children}</div>
    </Card>
  )
}

export default function NewVisit() {
  const nav = useNavigate()
  const toast = useToast()
  const [pid, setPid] = useState(waitingList[0].patientId)
  const [labs, setLabs] = useState(['HBA1C'])
  const [followUp, setFollowUp] = useState('2 أسابيع')
  const p = patients.find((x) => x.id === pid)

  const toggleLab = (code) => setLabs((s) => (s.includes(code) ? s.filter((c) => c !== code) : [...s, code]))

  const save = () => {
    toast('حُفظت الزيارة وأُضيفت إلى ملف المريض')
    nav(`/patients/${pid}`)
  }

  return (
    <>
      <PageHeader
        eyebrow="زيارة جديدة"
        title="تسجيل زيارة"
        sub="املأ ما تحتاجه فقط — كل حقل تتركه فارغاً لن يظهر في تقرير الزيارة."
        actions={
          <>
            <Button variant="outline" icon={Save} onClick={() => toast('حُفظت كمسودة')}>حفظ كمسودة</Button>
            <Button variant="gold" icon={Check} onClick={save}>إنهاء الزيارة</Button>
          </>
        }
      />

      <div className="grid gap-4 lg:grid-cols-[1fr_260px]">
        <div className="space-y-4">
          {/* المريض */}
          <Section id="who" n={1} title="المريض" sub="اختر من قائمة الانتظار أو ابحث في السجل" icon={Stethoscope}>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="اسم المريض" required>
                <Select value={pid} onChange={(e) => setPid(e.target.value)}>
                  {patients.map((x) => (
                    <option key={x.id} value={x.id}>{x.name} — {x.id}</option>
                  ))}
                </Select>
              </Field>
              <Field label="نوع الزيارة" required>
                <Select defaultValue="متابعة">
                  <option>كشف أول</option>
                  <option>متابعة</option>
                  <option>طارئ</option>
                  <option>استشارة</option>
                </Select>
              </Field>
            </div>

            {p && (
              <div className="mt-4 flex flex-wrap items-center gap-3 rounded-xl border border-line bg-mist p-3.5">
                <Avatar initials={p.initials} size="sm" ring={p.risk === 'مرتفع'} />
                <div className="min-w-0">
                  <p className="text-[13.5px] font-bold text-navy-900">{p.name}</p>
                  <p className="num text-[11.5px] text-navy-400">{p.age} سنة · {p.gender} · {p.blood} · {p.id}</p>
                </div>
                <div className="ms-auto flex flex-wrap items-center gap-1.5">
                  {!p.allergies[0]?.includes('لا توجد') && <Badge tone="danger" dot>حساسية مسجّلة</Badge>}
                  {p.chronic.slice(0, 2).map((c) => <Badge key={c} tone="neutral">{c}</Badge>)}
                  <Button size="sm" variant="ghost" icon={ChevronRight} onClick={() => nav(`/patients/${p.id}`)}>الملف</Button>
                </div>
              </div>
            )}
          </Section>

          {/* الشكوى */}
          <Section id="complaint" n={2} title="الشكوى الرئيسية" sub="بكلمات المريض قدر الإمكان" icon={ClipboardList}>
            <div className="grid gap-4">
              <Field label="الشكوى الرئيسية" required>
                <Input placeholder="مثال: ألم حارق في الصدر بعد الأكل" />
              </Field>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="مدة الأعراض">
                  <Select defaultValue="">
                    <option value="" disabled>اختر المدة</option>
                    {['أقل من يوم', '2–3 أيام', 'أسبوع', 'أسبوعان', 'شهر', '3 أشهر', 'أكثر من 6 أشهر'].map((d) => <option key={d}>{d}</option>)}
                  </Select>
                </Field>
                <Field label="شدة الأعراض" hint="من 1 إلى 10 بحسب وصف المريض">
                  <Input type="number" min="1" max="10" placeholder="6" dir="ltr" className="text-right" />
                </Field>
              </div>
              <Field label="تفاصيل إضافية" hint="محفزات، عوامل مخففة، أعراض مصاحبة">
                <Textarea rows={3} placeholder="يزداد عند الاستلقاء ويخف بمضادات الحموضة، لا يصاحبه ضيق نفس." />
              </Field>
            </div>
          </Section>

          {/* العلامات الحيوية */}
          <Section id="vitals" n={3} title="العلامات الحيوية" sub="تُسجّل عادة من المساعد قبل دخول الطبيب" icon={HeartPulse}>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {[
                { label: 'ضغط الدم', icon: Gauge, ph: '120/80', unit: 'ملم زئبق' },
                { label: 'النبض', icon: HeartPulse, ph: '72', unit: 'نبضة/د' },
                { label: 'الحرارة', icon: Thermometer, ph: '36.8', unit: '°م' },
                { label: 'تشبع الأكسجين', icon: Wind, ph: '98', unit: '%' },
                { label: 'الوزن', icon: Scale, ph: '78', unit: 'كغ' },
                { label: 'الطول', icon: Scale, ph: '172', unit: 'سم' },
                { label: 'سكر الدم', icon: Droplet, ph: '95', unit: 'ملغ/دل' },
                { label: 'معدل التنفس', icon: Wind, ph: '16', unit: 'نفس/د' },
              ].map((v) => (
                <label key={v.label} className="block">
                  <span className="mb-1.5 flex items-center gap-1.5 text-[12px] font-semibold text-navy-700">
                    <v.icon size={12} className="text-navy-300" />
                    {v.label}
                  </span>
                  <div className="relative">
                    <Input placeholder={v.ph} dir="ltr" className="pe-3 text-right" />
                    <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[10.5px] text-navy-300">{v.unit}</span>
                  </div>
                </label>
              ))}
            </div>
          </Section>

          {/* الفحص والتشخيص */}
          <Section id="exam" n={4} title="الفحص السريري والتشخيص" sub="ما وجدته بالفحص، ثم ما استقررت عليه" icon={NotebookPen}>
            <div className="grid gap-4">
              <Field label="الفحص السريري">
                <Textarea rows={4} placeholder="القلب: أصوات طبيعية بلا لغط. الرئتان: دخول هواء متساوٍ. البطن: لين غير مؤلم." />
              </Field>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="التشخيص المبدئي" hint="ما ترجّحه قبل النتائج">
                  <Input placeholder="مثال: ارتجاع مريئي" />
                </Field>
                <Field label="التشخيص النهائي" required hint="يظهر في ملف المريض وسجل التشخيصات">
                  <Input placeholder="مثال: ألم صدري غير قلبي — منشأ مريئي" />
                </Field>
              </div>
            </div>
          </Section>

          {/* الخطة */}
          <Section id="plan" n={5} title="الخطة العلاجية والمتابعة" sub="ما سيفعله المريض بعد خروجه من الغرفة" icon={CalendarPlus}>
            <div className="grid gap-4">
              <Field label="الخطة العلاجية" required>
                <Textarea rows={3} placeholder="بدء أوميبرازول 20 ملغ لأربعة أسابيع، رفع الرأس أثناء النوم، تجنب الأكل قبل النوم بساعتين." />
              </Field>

              <div>
                <p className="mb-2 flex items-center gap-1.5 text-[12.5px] font-semibold text-navy-700">
                  <FlaskConical size={13} className="text-navy-300" />
                  طلب فحوصات
                  <span className="num ms-1 rounded-md bg-teal-50 px-1.5 text-[11px] font-bold text-teal-700">{labs.length}</span>
                </p>
                <div className="flex flex-wrap gap-2">
                  {labCatalog.map((l) => {
                    const on = labs.includes(l.code)
                    return (
                      <button
                        key={l.code}
                        onClick={() => toggleLab(l.code)}
                        className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-[12.5px] transition-colors ${
                          on ? 'border-teal-500 bg-teal-50 font-semibold text-teal-700' : 'border-line bg-white text-navy-500 hover:border-navy-200'
                        }`}
                      >
                        {on && <Check size={12} />}
                        {l.name}
                      </button>
                    )
                  })}
                </div>
              </div>

              <Field label="ملاحظات الطبيب" hint="خاصة بك — لا تظهر في تقرير المريض">
                <Textarea rows={3} placeholder="طُمئن بعد استبعاد المنشأ القلبي. يُعاد التقييم إن لم يستجب خلال أسبوعين." />
              </Field>

              <div>
                <p className="mb-2 text-[12.5px] font-semibold text-navy-700">موعد المراجعة</p>
                <div className="flex flex-wrap gap-2">
                  {['أسبوع', '2 أسابيع', 'شهر', '3 أشهر', 'عند اللزوم'].map((f) => (
                    <button
                      key={f}
                      onClick={() => setFollowUp(f)}
                      className={`rounded-lg border px-3.5 py-1.5 text-[12.5px] transition-colors ${
                        followUp === f ? 'border-gold-400 bg-gold-50 font-semibold text-gold-600' : 'border-line bg-white text-navy-500 hover:border-navy-200'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </Section>
        </div>

        {/* دليل التنقل */}
        <aside className="hidden lg:block">
          <div className="sticky top-24 space-y-4">
            <Card className="p-4">
              <p className="eyebrow mb-3">أقسام النموذج</p>
              <nav className="space-y-0.5">
                {sections.map((s, i) => (
                  <a
                    key={s.key}
                    href={`#${s.key}`}
                    className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] text-navy-500 transition-colors hover:bg-mist hover:text-navy-900"
                  >
                    <span className="num text-[10.5px] font-semibold text-navy-200">{String(i + 1).padStart(2, '0')}</span>
                    <s.icon size={14} className="text-navy-300" />
                    {s.label}
                  </a>
                ))}
              </nav>
            </Card>

            {p && !p.allergies[0]?.includes('لا توجد') && (
              <Card className="border-[#F0D2D3] bg-[#FDF4F4] p-4">
                <p className="text-[12px] font-bold text-clay">تنبيه حساسية</p>
                <ul className="mt-2 space-y-1 text-[12.5px] leading-relaxed text-navy-700">
                  {p.allergies.map((a) => <li key={a}>· {a}</li>)}
                </ul>
              </Card>
            )}

            <Card className="p-4">
              <p className="eyebrow mb-2">رسوم الزيارة</p>
              <p className="num font-display text-[24px] font-extrabold text-navy-950">250 <span className="text-[12px] font-medium text-navy-400">ر.س</span></p>
              <p className="mt-1 text-[11.5px] text-navy-300">تُحتسب تلقائياً حسب نوع الزيارة.</p>
            </Card>
          </div>
        </aside>
      </div>
    </>
  )
}
