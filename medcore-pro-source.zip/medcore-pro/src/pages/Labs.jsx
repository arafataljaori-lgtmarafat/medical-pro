import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { FlaskConical, Plus, FileText, Image, Download, Search, Check, Upload, TriangleAlert, Paperclip } from 'lucide-react'
import { PageHeader } from '../components/Layout'
import { Badge, Button, Card, CardHead, Empty, Field, Input, Modal, Select, statusTone, useToast } from '../components/ui'
import { attachments, labCatalog, labOrders, patients } from '../data/mockData'

const STATES = ['الكل', 'مطلوب', 'قيد الانتظار', 'جاهز']
const flagColor = (f) => (['حرج', 'مرتفع', 'منخفض'].includes(f) ? 'text-clay' : f === 'طبيعي' ? 'text-[#1D7A45]' : 'text-navy-400')

export default function Labs() {
  const nav = useNavigate()
  const toast = useToast()
  const [tab, setTab] = useState('orders')
  const [state, setState] = useState('الكل')
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(false)
  const [picked, setPicked] = useState(['CBC'])

  const rows = useMemo(
    () =>
      labOrders.filter((l) => {
        if (state !== 'الكل' && l.status !== state) return false
        if (q.trim() && !(l.patientName.includes(q) || l.test.includes(q))) return false
        return true
      }),
    [state, q]
  )

  const counts = {
    مطلوب: labOrders.filter((l) => l.status === 'مطلوب').length,
    'قيد الانتظار': labOrders.filter((l) => l.status === 'قيد الانتظار').length,
    جاهز: labOrders.filter((l) => l.status === 'جاهز').length,
    حرج: labOrders.filter((l) => l.flag === 'حرج').length,
  }

  return (
    <>
      <PageHeader
        eyebrow="التشخيص"
        title="الفحوصات والمرفقات"
        sub="طلبات المختبر والأشعة ونتائجها، مع كل ملف مرفوع على ملفات المرضى."
        actions={
          <>
            <Button variant="outline" icon={Upload} onClick={() => toast('اختر ملفاً لرفعه على ملف المريض')}>رفع مرفق</Button>
            <Button variant="gold" icon={Plus} onClick={() => setOpen(true)}>طلب فحوصات</Button>
          </>
        }
      />

      {counts.حرج > 0 && (
        <div className="mb-4 flex flex-wrap items-center gap-3 rounded-2xl border border-[#F0D2D3] bg-[#FDF4F4] px-5 py-4">
          <TriangleAlert size={17} className="shrink-0 text-clay" />
          <p className="text-[13px] font-semibold text-clay">
            {counts.حرج} نتيجة حرجة تنتظر مراجعتك — راجعها قبل أي قرار علاجي.
          </p>
          <Button size="sm" variant="danger" onClick={() => { setState('جاهز'); setTab('orders') }} className="ms-auto">
            عرض النتائج الحرجة
          </Button>
        </div>
      )}

      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: 'مطلوب', value: counts.مطلوب, hint: 'لم يُسحب بعد' },
          { label: 'قيد الانتظار', value: counts['قيد الانتظار'], hint: 'في المختبر' },
          { label: 'جاهز', value: counts.جاهز, hint: 'نتيجة متاحة' },
          { label: 'مرفقات', value: attachments.length, hint: 'ملفات وصور' },
        ].map((s) => (
          <Card key={s.label} className="p-5">
            <p className="text-[12px] font-medium text-navy-400">{s.label}</p>
            <p className="num mt-1.5 font-display text-[28px] font-extrabold leading-none text-navy-950">{s.value}</p>
            <p className="mt-1.5 text-[11.5px] text-navy-300">{s.hint}</p>
          </Card>
        ))}
      </div>

      <div className="mb-4 flex gap-1 border-b border-line">
        {[
          { key: 'orders', label: 'طلبات الفحوصات', icon: FlaskConical },
          { key: 'files', label: 'المرفقات والصور', icon: Paperclip },
        ].map((t) => {
          const on = tab === t.key
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`relative flex items-center gap-2 px-4 py-3 text-[13.5px] ${on ? 'font-bold text-navy-950' : 'text-navy-400 hover:text-navy-700'}`}
            >
              <t.icon size={15} className={on ? 'text-teal-500' : ''} />
              {t.label}
              {on && <span className="absolute inset-x-3 -bottom-px h-0.5 rounded-full bg-teal-500" />}
            </button>
          )
        })}
      </div>

      {tab === 'orders' ? (
        <Card>
          <div className="flex flex-col gap-3 border-b border-line p-4 sm:flex-row">
            <div className="relative flex-1">
              <Search size={16} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-navy-300" />
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث باسم المريض أو الفحص" className="pe-10" />
            </div>
            <div className="flex gap-1 rounded-xl border border-line p-1">
              {STATES.map((s) => (
                <button
                  key={s}
                  onClick={() => setState(s)}
                  className={`rounded-lg px-3 py-1.5 text-[12.5px] transition-colors ${state === s ? 'bg-navy-950 font-semibold text-white' : 'text-navy-500 hover:bg-mist'}`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {rows.length === 0 ? (
            <Empty icon={FlaskConical} title="لا توجد طلبات بهذه الحالة" body="غيّر الحالة أو اطلب فحصاً جديداً." action={<Button variant="outline" onClick={() => setOpen(true)}>طلب فحوصات</Button>} />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right">
                <thead>
                  <tr className="border-b border-line bg-mist text-[11.5px] font-semibold text-navy-400">
                    <th className="px-5 py-3 font-semibold">الفحص</th>
                    <th className="px-3 py-3 font-semibold">المريض</th>
                    <th className="px-3 py-3 font-semibold">تاريخ الطلب</th>
                    <th className="px-3 py-3 font-semibold">النتيجة</th>
                    <th className="px-3 py-3 font-semibold">المدى الطبيعي</th>
                    <th className="px-3 py-3 font-semibold">الحالة</th>
                    <th className="px-5 py-3 font-semibold"></th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((l) => (
                    <tr key={l.id} className="border-b border-line last:border-0 hover:bg-mist">
                      <td className="px-5 py-3">
                        <p className="text-[13px] font-semibold text-navy-900">{l.test}</p>
                        <p className="num text-[11px] text-navy-300">{l.id} · {l.code}</p>
                      </td>
                      <td className="px-3 py-3 text-[13px] text-navy-600">{l.patientName}</td>
                      <td className="num px-3 py-3 text-[12.5px] text-navy-500">{l.ordered}</td>
                      <td className={`num px-3 py-3 text-[13px] font-semibold ${flagColor(l.flag)}`}>{l.result}</td>
                      <td className="num px-3 py-3 text-[12.5px] text-navy-400">{l.range}</td>
                      <td className="px-3 py-3">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <Badge tone={statusTone(l.status)}>{l.status}</Badge>
                          {l.urgency === 'عاجل' && <Badge tone="danger" dot>عاجل</Badge>}
                          {l.flag === 'حرج' && <Badge tone="danger">حرج</Badge>}
                        </div>
                      </td>
                      <td className="px-5 py-3">
                        <Button size="sm" variant="outline" onClick={() => nav(`/patients/${l.patientId}`)}>الملف</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      ) : (
        <Card>
          <CardHead title="المرفقات" sub="تقارير PDF وصور طبية مرتبطة بملفات المرضى" icon={Paperclip} />
          <div className="grid gap-3 border-t border-line p-5 sm:grid-cols-2 lg:grid-cols-3">
            {attachments.map((f) => {
              const p = patients.find((x) => x.id === f.patientId)
              return (
                <div key={f.id} className="group rounded-xl border border-line p-4 transition-colors hover:border-navy-200 hover:bg-mist">
                  <div className="flex items-start gap-3">
                    <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-lg ${f.kind === 'pdf' ? 'bg-[#FCEEEE] text-clay' : 'bg-teal-50 text-teal-600'}`}>
                      {f.kind === 'pdf' ? <FileText size={18} /> : <Image size={18} />}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-semibold text-navy-900">{f.name}</p>
                      <p className="num mt-0.5 text-[11.5px] text-navy-400">{f.size} · {f.date}</p>
                    </div>
                    <button className="grid h-8 w-8 place-items-center rounded-lg text-navy-300 opacity-0 transition-opacity hover:bg-white group-hover:opacity-100" aria-label="تنزيل">
                      <Download size={15} />
                    </button>
                  </div>
                  <div className="mt-3 flex items-center justify-between border-t border-line pt-3">
                    <button onClick={() => nav(`/patients/${f.patientId}`)} className="text-[12px] font-semibold text-teal-600 hover:text-teal-700">
                      {p?.name}
                    </button>
                    <span className="text-[11px] text-navy-300">رفعه {f.by}</span>
                  </div>
                </div>
              )
            })}
          </div>
        </Card>
      )}

      {/* طلب فحوصات */}
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        wide
        title="طلب فحوصات"
        sub="اختر الفحوصات ثم حدد الأولوية — يصل الطلب للمختبر مباشرة."
        footer={
          <>
            <Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button variant="gold" onClick={() => { setOpen(false); toast(`أُرسل طلب ${picked.length} فحوصات إلى المختبر`) }}>
              إرسال الطلب
            </Button>
          </>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="المريض" required>
            <Select defaultValue="P-1042">
              {patients.map((p) => <option key={p.id} value={p.id}>{p.name} — {p.id}</option>)}
            </Select>
          </Field>
          <Field label="الأولوية">
            <Select defaultValue="عادي">
              <option>عادي</option>
              <option>عاجل</option>
              <option>حرج</option>
            </Select>
          </Field>
        </div>

        <p className="mb-2 mt-5 flex items-center gap-2 text-[12.5px] font-semibold text-navy-700">
          الفحوصات
          <span className="num rounded-md bg-teal-50 px-1.5 text-[11px] font-bold text-teal-700">{picked.length}</span>
        </p>
        <div className="flex flex-wrap gap-2">
          {labCatalog.map((l) => {
            const on = picked.includes(l.code)
            return (
              <button
                key={l.code}
                onClick={() => setPicked((s) => (on ? s.filter((c) => c !== l.code) : [...s, l.code]))}
                className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-[12.5px] transition-colors ${
                  on ? 'border-teal-500 bg-teal-50 font-semibold text-teal-700' : 'border-line text-navy-500 hover:border-navy-200'
                }`}
              >
                {on && <Check size={12} />}
                {l.name}
                <span className="text-[10px] text-navy-300">{l.group}</span>
              </button>
            )
          })}
        </div>

        <Field label="ملاحظات للمختبر" className="mt-5">
          <Input placeholder="مثال: المريضة صائمة منذ 10 ساعات" />
        </Field>
      </Modal>
    </>
  )
}
