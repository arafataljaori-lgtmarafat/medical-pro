import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Stethoscope, Search, FolderOpen } from 'lucide-react'
import { PageHeader } from '../components/Layout'
import { Avatar, Badge, Button, Card, Empty, Input, Select } from '../components/ui'
import { patients, visits } from '../data/mockData'

const typeTone = { 'كشف أول': 'gold', 'متابعة': 'teal', 'طارئ': 'danger' }

export default function Visits() {
  const nav = useNavigate()
  const [q, setQ] = useState('')
  const [type, setType] = useState('كل الأنواع')

  const rows = useMemo(
    () =>
      visits
        .map((v) => ({ ...v, patient: patients.find((p) => p.id === v.patientId) }))
        .filter((v) => {
          if (type !== 'كل الأنواع' && v.type !== type) return false
          if (q.trim() && !(v.patient?.name.includes(q) || v.finalDx.includes(q) || v.id.toLowerCase().includes(q.toLowerCase()))) return false
          return true
        })
        .sort((a, b) => new Date(b.date) - new Date(a.date)),
    [q, type]
  )

  return (
    <>
      <PageHeader
        eyebrow="السجل الطبي"
        title="الزيارات"
        sub="كل زيارة سُجّلت في العيادة مع تشخيصها النهائي. اضغط الزيارة لفتح ملف المريض."
        actions={<Button variant="gold" icon={Stethoscope} onClick={() => nav('/visits/new')}>زيارة جديدة</Button>}
      />

      <Card className="mb-4 p-4">
        <div className="grid gap-3 md:grid-cols-[1fr_auto]">
          <div className="relative">
            <Search size={16} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-navy-300" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث باسم المريض أو التشخيص أو رقم الزيارة" className="pe-10" />
          </div>
          <Select value={type} onChange={(e) => setType(e.target.value)} className="md:w-44">
            {['كل الأنواع', 'كشف أول', 'متابعة', 'طارئ'].map((t) => <option key={t}>{t}</option>)}
          </Select>
        </div>
      </Card>

      {rows.length === 0 ? (
        <Card><Empty icon={Stethoscope} title="لا توجد زيارات مطابقة" body="جرّب تغيير النوع أو كلمة البحث." /></Card>
      ) : (
        <div className="space-y-3">
          {rows.map((v) => (
            <Card key={v.id} className="p-5 transition-colors hover:border-navy-200">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <Avatar initials={v.patient?.initials} />
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-[14px] font-bold text-navy-900">{v.patient?.name}</p>
                      <Badge tone={typeTone[v.type]}>{v.type}</Badge>
                    </div>
                    <p className="num mt-0.5 text-[11.5px] text-navy-400">{v.id} · {v.date} · {v.time} · {v.doctor}</p>
                  </div>
                </div>

                <div className="min-w-0 flex-[2] lg:border-r lg:border-line lg:pe-5">
                  <p className="eyebrow mb-1">التشخيص النهائي</p>
                  <p className="text-[13.5px] font-semibold leading-snug text-navy-900">{v.finalDx}</p>
                  <p className="mt-0.5 truncate text-[12.5px] text-navy-400">{v.complaint}</p>
                </div>

                <div className="flex shrink-0 items-center gap-4">
                  <div className="hidden text-right sm:block">
                    <p className="eyebrow mb-1">العلامات</p>
                    <p className="num text-[12.5px] text-navy-600">{v.vitals.bp} · {v.vitals.hr} نبضة</p>
                  </div>
                  <Button size="sm" variant="outline" icon={FolderOpen} onClick={() => nav(`/patients/${v.patientId}`)}>الملف</Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </>
  )
}
