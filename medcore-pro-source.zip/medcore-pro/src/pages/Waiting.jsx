import { useNavigate } from 'react-router-dom'
import { Hourglass, Plus, ArrowLeft, Stethoscope, Clock, DoorOpen, Timer } from 'lucide-react'
import { PageHeader } from '../components/Layout'
import { Avatar, Badge, Button, Card, useToast } from '../components/ui'
import { waitingList } from '../data/mockData'

const columns = [
  { key: 'ينتظر', title: 'في صالة الانتظار', tone: 'neutral' },
  { key: 'جاهز', title: 'جاهز للدخول', tone: 'green' },
  { key: 'في الغرفة', title: 'داخل الغرفة', tone: 'teal' },
]

export default function Waiting() {
  const nav = useNavigate()
  const toast = useToast()
  const avg = Math.round(waitingList.reduce((s, w) => s + w.waited, 0) / waitingList.length)
  const longest = Math.max(...waitingList.map((w) => w.waited))

  return (
    <>
      <PageHeader
        eyebrow="الآن في العيادة"
        title="قائمة الانتظار"
        sub={`متوسط الانتظار ${avg} دقيقة، وأطول انتظار ${longest} دقيقة. الحالات العاجلة تتقدم الصف تلقائياً.`}
        actions={
          <>
            <Button variant="outline" icon={Plus} onClick={() => toast('أُضيف المريض إلى الصف')}>إضافة للصف</Button>
            <Button variant="gold" icon={Stethoscope} onClick={() => nav('/visits/new')}>استدعاء التالي</Button>
          </>
        }
      />

      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: 'في الانتظار', value: waitingList.length, icon: Hourglass },
          { label: 'متوسط الانتظار', value: `${avg} د`, icon: Timer },
          { label: 'أطول انتظار', value: `${longest} د`, icon: Clock },
          { label: 'الغرف المشغولة', value: `1 / 3`, icon: DoorOpen },
        ].map((s) => (
          <Card key={s.label} className="p-5">
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-navy-50 text-navy-600">
              <s.icon size={17} strokeWidth={1.8} />
            </span>
            <p className="mt-4 text-[12px] font-medium text-navy-400">{s.label}</p>
            <p className="num mt-1 font-display text-[26px] font-extrabold leading-none text-navy-950">{s.value}</p>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {columns.map((col) => {
          const items = waitingList.filter((w) => w.state === col.key)
          return (
            <Card key={col.key} className="flex flex-col">
              <div className="flex items-center justify-between px-5 py-4">
                <h3 className="text-[14px] font-bold text-navy-900">{col.title}</h3>
                <Badge tone={col.tone}>{items.length}</Badge>
              </div>
              <div className="flex-1 space-y-3 border-t border-line bg-mist/60 p-3">
                {items.length === 0 ? (
                  <p className="px-2 py-8 text-center text-[12.5px] text-navy-300">لا أحد هنا الآن.</p>
                ) : (
                  items.map((w) => (
                    <div key={w.id} className="rounded-xl border border-line bg-white p-3.5 shadow-card">
                      <div className="flex items-center gap-2.5">
                        <span className="num rounded-md bg-navy-950 px-1.5 py-0.5 text-[10.5px] font-bold text-teal-300">{w.ticket}</span>
                        {w.priority === 'عاجل' && <Badge tone="danger" dot>عاجل</Badge>}
                        <span className="num ms-auto flex items-center gap-1 text-[11.5px] text-navy-400">
                          <Clock size={11} />{w.waited} د
                        </span>
                      </div>
                      <div className="mt-3 flex items-center gap-2.5">
                        <Avatar initials={w.initials} size="sm" ring={w.priority === 'عاجل'} />
                        <div className="min-w-0">
                          <p className="truncate text-[13.5px] font-bold text-navy-900">{w.name}</p>
                          <p className="num text-[11.5px] text-navy-400">{w.age} سنة · وصل {w.arrived}</p>
                        </div>
                      </div>
                      <p className="mt-2.5 rounded-lg bg-mist px-2.5 py-2 text-[12.5px] leading-relaxed text-navy-600">{w.reason}</p>
                      <div className="mt-3 flex gap-2">
                        <Button size="sm" variant="outline" icon={ArrowLeft} onClick={() => nav(`/patients/${w.patientId}`)} className="flex-1">الملف</Button>
                        <Button size="sm" variant={w.state === 'في الغرفة' ? 'teal' : 'primary'} icon={Stethoscope} onClick={() => nav('/visits/new')} className="flex-1">
                          {w.state === 'في الغرفة' ? 'متابعة' : 'استدعاء'}
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </Card>
          )
        })}
      </div>
    </>
  )
}
