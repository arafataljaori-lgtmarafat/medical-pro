import { Link, useNavigate, useOutletContext } from 'react-router-dom'
import {
  Users, CalendarDays, Hourglass, RotateCcw, Wallet, Plus, Stethoscope,
  ArrowLeft, TriangleAlert, ChevronLeft, Clock, DoorOpen,
} from 'lucide-react'
import { PageHeader } from '../components/Layout'
import { Avatar, Badge, Button, Card, CardHead, Sparkline, statusTone } from '../components/ui'
import { alerts, appointments, currentUser, todayStats, waitingList, clinic } from '../data/mockData'

const levelTone = { 'حرج': 'danger', 'تحذير': 'gold', 'معلومة': 'teal' }

function Stat({ label, value, unit, icon: Icon, trend, accent = false, spark }) {
  return (
    <Card className={`relative overflow-hidden p-5 ${accent ? 'border-gold-200 bg-gold-50/40' : ''}`}>
      <div className="flex items-start justify-between">
        <span className={`grid h-9 w-9 place-items-center rounded-lg ${accent ? 'bg-gold-400/20 text-gold-600' : 'bg-navy-50 text-navy-600'}`}>
          <Icon size={17} strokeWidth={1.8} />
        </span>
        {trend && (
          <span className={`num text-[11px] font-semibold ${trend.startsWith('-') ? 'text-clay' : 'text-teal-600'}`}>{trend}</span>
        )}
      </div>
      <p className="mt-4 text-[12px] font-medium text-navy-400">{label}</p>
      <p className="mt-1 flex items-baseline gap-1.5">
        <span className="num font-display text-[28px] font-extrabold leading-none text-navy-950">{value}</span>
        {unit && <span className="text-[12px] font-medium text-navy-400">{unit}</span>}
      </p>
      {spark && (
        <div className="pointer-events-none absolute inset-x-0 bottom-0 opacity-70">
          <Sparkline data={spark} height={28} stroke={accent ? '#C9A227' : '#12A5A5'} fill={accent ? 'rgba(201,162,39,.12)' : 'rgba(18,165,165,.1)'} />
        </div>
      )}
    </Card>
  )
}

export default function Dashboard() {
  const nav = useNavigate()
  const { openNewPatient } = useOutletContext()
  const today = appointments.filter((a) => a.date === '2026-07-17')

  return (
    <>
      <PageHeader
        eyebrow="الجمعة · 17 يوليو 2026"
        title={`صباح الخير، ${currentUser.name.replace('د. ', 'د. ')}`}
        sub={`${waitingList.length} مرضى في الانتظار الآن، وأقرب موعد بعد 12 دقيقة. لديك تنبيه حرج واحد يحتاج قراراً.`}
        actions={
          <>
            <Button variant="outline" icon={Plus} onClick={openNewPatient}>مريض جديد</Button>
            <Button variant="gold" icon={Stethoscope} onClick={() => nav('/visits/new')}>بدء زيارة</Button>
          </>
        }
      />

      {/* الإحصائيات */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <Stat label="مرضى اليوم" value={todayStats.patients} icon={Users} trend="+3" spark={[6, 8, 7, 10, 9, 12]} />
        <Stat label="مواعيد اليوم" value={todayStats.appointments} icon={CalendarDays} spark={[5, 6, 6, 7, 8, 8]} />
        <Stat label="في الانتظار" value={todayStats.waiting} icon={Hourglass} trend="+2" />
        <Stat label="مراجعات قادمة" value={todayStats.followUps} icon={RotateCcw} />
        <Stat
          label="إيراد اليوم"
          value={todayStats.revenue.toLocaleString('en-US')}
          unit={clinic.currency}
          icon={Wallet}
          trend="+14%"
          accent
          spark={[1200, 1450, 1600, 1900, 2100, 2340]}
        />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        {/* قائمة الانتظار */}
        <Card className="lg:col-span-2">
          <CardHead
            title="قائمة الانتظار"
            sub="مرتبة حسب الأولوية ثم وقت الوصول"
            icon={Hourglass}
            action={
              <Link to="/waiting" className="flex items-center gap-1 text-[12.5px] font-semibold text-teal-600 hover:text-teal-700">
                عرض الكل <ChevronLeft size={14} />
              </Link>
            }
          />
          <div className="border-t border-line">
            {waitingList.map((w, i) => (
              <div key={w.id} className="flex items-center gap-3 border-b border-line px-5 py-3.5 last:border-0 hover:bg-mist">
                <span className="num w-10 shrink-0 text-[12px] font-semibold text-navy-300">{w.ticket}</span>
                <Avatar initials={w.initials} size="sm" ring={w.priority === 'عاجل'} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13.5px] font-semibold text-navy-900">{w.name}</p>
                  <p className="truncate text-[12px] text-navy-400">{w.reason}</p>
                </div>
                <div className="hidden shrink-0 items-center gap-2 sm:flex">
                  {w.priority === 'عاجل' && <Badge tone="danger" dot>عاجل</Badge>}
                  <Badge tone={statusTone(w.state)}>{w.state}</Badge>
                </div>
                <span className="num hidden w-16 shrink-0 text-left text-[12px] text-navy-400 md:block">{w.waited} د</span>
                <Button size="sm" variant="outline" icon={ArrowLeft} onClick={() => nav(`/patients/${w.patientId}`)}>
                  الملف
                </Button>
              </div>
            ))}
          </div>
        </Card>

        {/* التنبيهات */}
        <Card>
          <CardHead title="تنبيهات تحتاج قراراً" sub="نتائج حرجة وتعارضات ومواعيد متأخرة" icon={TriangleAlert} />
          <div className="border-t border-line">
            {alerts.slice(0, 4).map((a) => (
              <button
                key={a.id}
                onClick={() => nav(`/patients/${a.patientId}`)}
                className="block w-full border-b border-line px-5 py-3.5 text-right last:border-0 hover:bg-mist"
              >
                <div className="flex items-center gap-2">
                  <Badge tone={levelTone[a.level]} dot={a.level === 'حرج'}>{a.level}</Badge>
                  <span className="text-[11px] text-navy-300">{a.time}</span>
                </div>
                <p className="mt-1.5 text-[13px] font-semibold leading-snug text-navy-900">{a.title}</p>
                <p className="mt-1 text-[12px] leading-relaxed text-navy-400">{a.body}</p>
              </button>
            ))}
          </div>
        </Card>
      </div>

      {/* مواعيد اليوم */}
      <Card className="mt-4">
        <CardHead
          title="مواعيد اليوم"
          sub={`${today.length} مواعيد — ${today.filter((a) => a.status === 'مكتمل').length} مكتملة`}
          icon={CalendarDays}
          action={
            <Link to="/appointments" className="flex items-center gap-1 text-[12.5px] font-semibold text-teal-600 hover:text-teal-700">
              التقويم <ChevronLeft size={14} />
            </Link>
          }
        />
        <div className="grid gap-px border-t border-line bg-line sm:grid-cols-2 xl:grid-cols-4">
          {today.map((a) => (
            <button
              key={a.id}
              onClick={() => nav(`/patients/${a.patientId}`)}
              className="bg-white p-4 text-right transition-colors hover:bg-mist"
            >
              <div className="flex items-center justify-between">
                <span className="num flex items-center gap-1.5 text-[13px] font-bold text-navy-900">
                  <Clock size={13} className="text-navy-300" />
                  {a.time}
                </span>
                <Badge tone={statusTone(a.status)}>{a.status}</Badge>
              </div>
              <div className="mt-3 flex items-center gap-2.5">
                <Avatar initials={a.initials} size="sm" />
                <div className="min-w-0">
                  <p className="truncate text-[13px] font-semibold text-navy-900">{a.name}</p>
                  <p className="text-[11.5px] text-navy-400">{a.type}</p>
                </div>
              </div>
              <div className="mt-3 flex items-center gap-3 border-t border-line pt-3 text-[11.5px] text-navy-400">
                <span className="num flex items-center gap-1"><Clock size={11} />{a.duration} دقيقة</span>
                <span className="flex items-center gap-1"><DoorOpen size={11} />{a.room}</span>
              </div>
            </button>
          ))}
        </div>
      </Card>
    </>
  )
}
