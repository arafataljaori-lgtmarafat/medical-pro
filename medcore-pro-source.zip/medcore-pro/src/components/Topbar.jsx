import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Menu, Search, Bell, ChevronDown, Plus, LogOut, UserCog, ShieldCheck, Check } from 'lucide-react'
import { patients, alerts, currentUser, roles } from '../data/mockData'
import { Avatar, Badge, Button } from './ui'

const levelTone = { 'حرج': 'danger', 'تحذير': 'gold', 'معلومة': 'teal' }

export default function Topbar({ onMenu, onNewPatient }) {
  const nav = useNavigate()
  const [q, setQ] = useState('')
  const [openSearch, setOpenSearch] = useState(false)
  const [openBell, setOpenBell] = useState(false)
  const [openUser, setOpenUser] = useState(false)
  const [role, setRole] = useState('الطبيب')
  const wrap = useRef(null)
  const inputRef = useRef(null)

  useEffect(() => {
    const onClick = (e) => {
      if (wrap.current && !wrap.current.contains(e.target)) {
        setOpenSearch(false)
        setOpenBell(false)
        setOpenUser(false)
      }
    }
    document.addEventListener('mousedown', onClick)
    return () => document.removeEventListener('mousedown', onClick)
  }, [])

  useEffect(() => {
    const onKey = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault()
        inputRef.current?.focus()
        setOpenSearch(true)
      }
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [])

  const results = q.trim()
    ? patients
        .filter((p) => p.name.includes(q) || p.phone.includes(q) || p.id.toLowerCase().includes(q.toLowerCase()))
        .slice(0, 6)
    : []

  const critical = alerts.filter((a) => a.level === 'حرج').length

  return (
    <header ref={wrap} className="sticky top-0 z-30 border-b border-line bg-white/85 backdrop-blur-md">
      <div className="flex h-16 items-center gap-3 px-4 sm:px-6">
        <button onClick={onMenu} className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-line text-navy-600 hover:bg-navy-50 lg:hidden" aria-label="فتح القائمة">
          <Menu size={17} />
        </button>

        {/* البحث */}
        <div className="relative min-w-0 flex-1 max-w-xl">
          <Search size={16} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-navy-300" />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => {
              setQ(e.target.value)
              setOpenSearch(true)
            }}
            onFocus={() => setOpenSearch(true)}
            placeholder="ابحث باسم المريض أو رقم الهاتف أو رقم الملف"
            className="h-10 w-full rounded-xl border border-line bg-mist pe-16 ps-10 text-[13px] text-navy-900 placeholder:text-navy-300 transition-colors focus:border-teal-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-100"
          />
          <kbd className="num pointer-events-none absolute left-3 top-1/2 hidden -translate-y-1/2 rounded border border-line bg-white px-1.5 py-0.5 text-[10px] text-navy-300 sm:block">
            Ctrl K
          </kbd>

          {openSearch && q.trim() && (
            <div className="absolute inset-x-0 top-12 overflow-hidden rounded-xl border border-line bg-white shadow-lift animate-rise">
              {results.length ? (
                results.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      nav(`/patients/${p.id}`)
                      setQ('')
                      setOpenSearch(false)
                    }}
                    className="flex w-full items-center gap-3 border-b border-line px-3.5 py-2.5 text-right last:border-0 hover:bg-mist"
                  >
                    <Avatar initials={p.initials} size="sm" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13px] font-semibold text-navy-900">{p.name}</span>
                      <span className="num block text-[11.5px] text-navy-400">{p.id} · {p.phone}</span>
                    </span>
                    <Badge tone="slate">{p.status}</Badge>
                  </button>
                ))
              ) : (
                <p className="px-4 py-6 text-center text-[13px] text-navy-400">
                  لا يوجد مريض بهذا الاسم أو الرقم. جرّب رقم الجوال كاملاً.
                </p>
              )}
            </div>
          )}
        </div>

        <div className="ms-auto flex items-center gap-2">
          <Button variant="gold" size="sm" icon={Plus} onClick={onNewPatient} className="hidden sm:inline-flex">
            مريض جديد
          </Button>

          {/* التنبيهات */}
          <div className="relative">
            <button
              onClick={() => {
                setOpenBell((v) => !v)
                setOpenUser(false)
              }}
              className="relative grid h-9 w-9 place-items-center rounded-lg border border-line text-navy-600 hover:bg-navy-50"
              aria-label="التنبيهات"
            >
              <Bell size={17} strokeWidth={1.8} />
              {critical > 0 && (
                <span className="num absolute -top-1.5 -left-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-clay px-1 text-[9.5px] font-bold text-white">
                  {alerts.length}
                </span>
              )}
            </button>

            {openBell && (
              <div className="absolute left-0 top-11 w-[330px] overflow-hidden rounded-xl border border-line bg-white shadow-lift animate-rise">
                <div className="flex items-center justify-between border-b border-line px-4 py-3">
                  <p className="text-[13.5px] font-bold text-navy-900">التنبيهات</p>
                  <Badge tone="danger" dot>{critical} حرج</Badge>
                </div>
                <div className="max-h-[340px] overflow-y-auto">
                  {alerts.map((a) => (
                    <button
                      key={a.id}
                      onClick={() => {
                        nav(`/patients/${a.patientId}`)
                        setOpenBell(false)
                      }}
                      className="block w-full border-b border-line px-4 py-3 text-right last:border-0 hover:bg-mist"
                    >
                      <div className="flex items-center gap-2">
                        <Badge tone={levelTone[a.level]}>{a.level}</Badge>
                        <span className="text-[11px] text-navy-300">{a.time}</span>
                      </div>
                      <p className="mt-1.5 text-[13px] font-semibold text-navy-900">{a.title}</p>
                      <p className="mt-0.5 text-[12px] leading-relaxed text-navy-400">{a.body}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* المستخدم */}
          <div className="relative">
            <button
              onClick={() => {
                setOpenUser((v) => !v)
                setOpenBell(false)
              }}
              className="flex items-center gap-2.5 rounded-lg border border-line py-1 pe-2 ps-1 hover:bg-navy-50"
            >
              <Avatar initials={currentUser.initials} size="sm" />
              <span className="hidden text-right sm:block">
                <span className="block text-[12.5px] font-bold leading-tight text-navy-900">{currentUser.name}</span>
                <span className="block text-[11px] text-navy-400">{role}</span>
              </span>
              <ChevronDown size={14} className="text-navy-300" />
            </button>

            {openUser && (
              <div className="absolute left-0 top-12 w-[260px] overflow-hidden rounded-xl border border-line bg-white shadow-lift animate-rise">
                <div className="border-b border-line bg-navy-950 grid-texture px-4 py-3.5">
                  <p className="text-[13.5px] font-bold text-white">{currentUser.name}</p>
                  <p className="text-[11.5px] text-navy-300/80">{currentUser.specialty}</p>
                </div>
                <div className="p-2">
                  <p className="px-2 pb-1 pt-1.5 text-[10.5px] font-semibold tracking-wider text-navy-300">
                    عرض الواجهة بصلاحية
                  </p>
                  {roles.map((r) => (
                    <button
                      key={r.key}
                      onClick={() => setRole(r.label)}
                      className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-right text-[13px] text-navy-700 hover:bg-mist"
                    >
                      <ShieldCheck size={15} className="text-navy-300" />
                      {r.label}
                      {role === r.label && <Check size={14} className="ms-auto text-teal-500" />}
                    </button>
                  ))}
                  <div className="my-1.5 h-px bg-line" />
                  <button
                    onClick={() => {
                      nav('/settings')
                      setOpenUser(false)
                    }}
                    className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-right text-[13px] text-navy-700 hover:bg-mist"
                  >
                    <UserCog size={15} className="text-navy-300" />
                    بيانات الطبيب والعيادة
                  </button>
                  <button className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-right text-[13px] text-clay hover:bg-[#FCEEEE]">
                    <LogOut size={15} />
                    إنهاء الجلسة
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
