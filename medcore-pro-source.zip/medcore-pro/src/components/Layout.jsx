import { useState } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import Sidebar from './Sidebar'
import Topbar from './Topbar'
import { Button, Field, Input, Modal, Select, useToast } from './ui'

export function PageHeader({ eyebrow, title, sub, actions }) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow && <p className="eyebrow mb-1.5">{eyebrow}</p>}
        <h1 className="font-display text-[24px] font-extrabold leading-tight text-navy-950 sm:text-[27px]">{title}</h1>
        {sub && <p className="mt-1.5 max-w-2xl text-[13.5px] leading-relaxed text-navy-400">{sub}</p>}
      </div>
      {actions && <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div>}
    </div>
  )
}

export function NewPatientModal({ open, onClose }) {
  const toast = useToast()
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="تسجيل مريض جديد"
      sub="البيانات الأساسية تكفي الآن — يمكن استكمال الملف الطبي في أول زيارة."
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>إلغاء</Button>
          <Button
            variant="gold"
            onClick={() => {
              onClose()
              toast('تم تسجيل المريض وإضافته إلى قائمة الانتظار')
            }}
          >
            حفظ وإضافة للانتظار
          </Button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="الاسم الكامل" required className="sm:col-span-2">
          <Input placeholder="مثال: عبدالله سعد المطيري" />
        </Field>
        <Field label="رقم الجوال" required>
          <Input placeholder="05xxxxxxxx" dir="ltr" className="text-right" />
        </Field>
        <Field label="رقم الهوية">
          <Input placeholder="10xxxxxxxx" dir="ltr" className="text-right" />
        </Field>
        <Field label="تاريخ الميلاد">
          <Input type="date" />
        </Field>
        <Field label="الجنس">
          <Select defaultValue="">
            <option value="" disabled>اختر</option>
            <option>ذكر</option>
            <option>أنثى</option>
          </Select>
        </Field>
        <Field label="فصيلة الدم">
          <Select defaultValue="">
            <option value="">غير معروفة</option>
            {['O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-'].map((b) => (
              <option key={b}>{b}</option>
            ))}
          </Select>
        </Field>
        <Field label="جهة التغطية">
          <Select defaultValue="دفع مباشر">
            <option>دفع مباشر</option>
            <option>بوبا</option>
            <option>تعاونية</option>
            <option>ملاذ</option>
          </Select>
        </Field>
        <Field label="سبب الزيارة" hint="يظهر للطبيب في قائمة الانتظار" className="sm:col-span-2">
          <Input placeholder="مثال: ألم أسفل الظهر منذ أسبوع" />
        </Field>
      </div>
    </Modal>
  )
}

export default function Layout() {
  const [menu, setMenu] = useState(false)
  const [newPatient, setNewPatient] = useState(false)
  const { pathname } = useLocation()

  return (
    <div className="min-h-screen lg:pe-[270px]">
      <Sidebar open={menu} onClose={() => setMenu(false)} />
      <div className="flex min-h-screen flex-col">
        <Topbar onMenu={() => setMenu(true)} onNewPatient={() => setNewPatient(true)} />
        <main key={pathname} className="flex-1 animate-rise px-4 py-6 sm:px-6 sm:py-8">
          <Outlet context={{ openNewPatient: () => setNewPatient(true) }} />
        </main>
        <footer className="border-t border-line px-6 py-4 text-center text-[11.5px] text-navy-300">
          MedCore Pro — نسخة عرض بواجهة فقط. جميع البيانات الظاهرة تجريبية ولا تخص أشخاصاً حقيقيين.
        </footer>
      </div>
      <NewPatientModal open={newPatient} onClose={() => setNewPatient(false)} />
    </div>
  )
}
