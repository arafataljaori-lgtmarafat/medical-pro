import { createContext, useContext, useEffect, useState } from 'react'
import { X } from 'lucide-react'

// ---------------------------------------------
// Button
// ---------------------------------------------
const variants = {
  primary:
    'bg-navy-900 text-white hover:bg-navy-800 active:bg-navy-950 shadow-card border border-navy-900',
  gold:
    'bg-gold-400 text-navy-950 hover:bg-gold-300 active:bg-gold-500 border border-gold-400 shadow-card font-semibold',
  teal: 'bg-teal-500 text-white hover:bg-teal-600 active:bg-teal-700 border border-teal-500 shadow-card',
  ghost: 'bg-transparent text-navy-600 hover:bg-navy-50 border border-transparent',
  outline: 'bg-white text-navy-800 border border-line hover:border-navy-300 hover:bg-navy-50',
  danger: 'bg-clay text-white hover:brightness-110 border border-clay',
}

const sizes = {
  sm: 'h-8 px-3 text-[12.5px] gap-1.5 rounded-lg',
  md: 'h-10 px-4 text-[13.5px] gap-2 rounded-xl',
  lg: 'h-12 px-5 text-[15px] gap-2.5 rounded-xl',
}

export function Button({ variant = 'primary', size = 'md', icon: Icon, children, className = '', ...props }) {
  return (
    <button
      className={`inline-flex items-center justify-center font-medium transition-all duration-150 disabled:opacity-40 disabled:pointer-events-none whitespace-nowrap ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {Icon && <Icon size={size === 'sm' ? 14 : 16} strokeWidth={2} />}
      {children}
    </button>
  )
}

// ---------------------------------------------
// Card
// ---------------------------------------------
export function Card({ className = '', children, ...props }) {
  return (
    <div className={`card ${className}`} {...props}>
      {children}
    </div>
  )
}

export function CardHead({ title, sub, icon: Icon, action, className = '' }) {
  return (
    <div className={`flex items-start justify-between gap-3 px-5 pt-5 pb-4 ${className}`}>
      <div className="flex items-start gap-3 min-w-0">
        {Icon && (
          <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-navy-50 text-navy-700">
            <Icon size={17} strokeWidth={1.8} />
          </span>
        )}
        <div className="min-w-0">
          <h3 className="text-[15px] font-bold text-navy-900 truncate">{title}</h3>
          {sub && <p className="text-[12.5px] text-navy-400 mt-0.5 truncate">{sub}</p>}
        </div>
      </div>
      {action}
    </div>
  )
}

// ---------------------------------------------
// Badge
// ---------------------------------------------
const tones = {
  neutral: 'bg-navy-50 text-navy-600 border-navy-100',
  teal: 'bg-teal-50 text-teal-700 border-teal-100',
  gold: 'bg-gold-50 text-gold-600 border-gold-100',
  danger: 'bg-[#FCEEEE] text-clay border-[#F3D6D7]',
  navy: 'bg-navy-900 text-white border-navy-900',
  green: 'bg-[#EAF7EF] text-[#1D7A45] border-[#CDEBD9]',
  slate: 'bg-white text-navy-400 border-line',
}

export function Badge({ tone = 'neutral', dot = false, children, className = '' }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11.5px] font-medium leading-5 ${tones[tone]} ${className}`}
    >
      {dot && <i className="h-1.5 w-1.5 rounded-full bg-current" />}
      {children}
    </span>
  )
}

// خريطة موحدة لحالات النظام → نغمة اللون
export const statusTone = (s) =>
  ({
    'حرج': 'danger',
    'عاجل': 'danger',
    'مرتفع': 'danger',
    'لم يحضر': 'danger',
    'حالة نشطة': 'teal',
    'جاهز': 'green',
    'حضر': 'green',
    'مكتمل': 'green',
    'مؤكد': 'teal',
    'طبيعي': 'green',
    'متابعة': 'navy',
    'جديد': 'gold',
    'مؤجل': 'gold',
    'قيد الانتظار': 'gold',
    'متوسط': 'gold',
    'مطلوب': 'slate',
    'منخفض': 'neutral',
    'ينتظر': 'neutral',
    'في الغرفة': 'teal',
  }[s] || 'neutral')

// ---------------------------------------------
// Avatar
// ---------------------------------------------
export function Avatar({ initials, size = 'md', ring = false, className = '' }) {
  const s = { sm: 'h-8 w-8 text-[11px]', md: 'h-10 w-10 text-[13px]', lg: 'h-14 w-14 text-[17px]', xl: 'h-20 w-20 text-[24px]' }[size]
  return (
    <span
      className={`grid shrink-0 place-items-center rounded-xl bg-gradient-to-br from-navy-800 to-navy-950 font-display font-bold text-white ${s} ${
        ring ? 'ring-2 ring-teal-400 ring-offset-2 ring-offset-white' : ''
      } ${className}`}
    >
      {initials}
    </span>
  )
}

// ---------------------------------------------
// Field / Input / Select / Textarea
// ---------------------------------------------
export function Field({ label, hint, required, children, className = '' }) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-1.5 flex items-center gap-1.5 text-[12.5px] font-semibold text-navy-700">
        {label}
        {required && <i className="h-1 w-1 rounded-full bg-clay" title="حقل مطلوب" />}
      </span>
      {children}
      {hint && <span className="mt-1 block text-[11.5px] text-navy-300">{hint}</span>}
    </label>
  )
}

const inputBase =
  'w-full rounded-xl border border-line bg-white px-3.5 text-[13.5px] text-navy-900 placeholder:text-navy-300 transition-colors hover:border-navy-200 focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-100'

export function Input({ className = '', ...props }) {
  return <input className={`${inputBase} h-10 ${className}`} {...props} />
}

export function Textarea({ className = '', rows = 3, ...props }) {
  return <textarea rows={rows} className={`${inputBase} py-2.5 leading-relaxed ${className}`} {...props} />
}

export function Select({ className = '', children, ...props }) {
  return (
    <select className={`${inputBase} h-10 cursor-pointer ${className}`} {...props}>
      {children}
    </select>
  )
}

// ---------------------------------------------
// Modal
// ---------------------------------------------
export function Modal({ open, onClose, title, sub, children, footer, wide = false }) {
  useEffect(() => {
    if (!open) return
    const onKey = (e) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [open, onClose])

  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-6">
      <div className="absolute inset-0 bg-navy-950/50 backdrop-blur-[2px]" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        className={`relative z-10 flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-2xl bg-white shadow-lift animate-rise sm:rounded-2xl ${
          wide ? 'sm:max-w-3xl' : 'sm:max-w-lg'
        }`}
      >
        <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4">
          <div>
            <h3 className="font-display text-[16px] font-bold text-navy-900">{title}</h3>
            {sub && <p className="mt-0.5 text-[12.5px] text-navy-400">{sub}</p>}
          </div>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-lg text-navy-400 hover:bg-navy-50" aria-label="إغلاق">
            <X size={16} />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-5">{children}</div>
        {footer && <div className="flex items-center justify-end gap-2 border-t border-line bg-mist px-5 py-3.5">{footer}</div>}
      </div>
    </div>
  )
}

// ---------------------------------------------
// Toast (إشعار تأكيد الإجراء)
// ---------------------------------------------
const ToastCtx = createContext(() => {})
export const useToast = () => useContext(ToastCtx)

export function ToastHost({ children }) {
  const [items, setItems] = useState([])
  const push = (text, tone = 'teal') => {
    const id = Math.random().toString(36).slice(2)
    setItems((p) => [...p, { id, text, tone }])
    setTimeout(() => setItems((p) => p.filter((i) => i.id !== id)), 3200)
  }
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed bottom-5 left-5 z-[60] flex flex-col gap-2">
        {items.map((i) => (
          <div
            key={i.id}
            className="animate-rise rounded-xl border border-navy-800 bg-navy-950 px-4 py-3 text-[13px] text-white shadow-lift"
          >
            <span className={`me-2 inline-block h-1.5 w-1.5 rounded-full align-middle ${i.tone === 'gold' ? 'bg-gold-400' : 'bg-teal-400'}`} />
            {i.text}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  )
}

// ---------------------------------------------
// Empty state
// ---------------------------------------------
export function Empty({ icon: Icon, title, body, action }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
      {Icon && (
        <span className="mb-4 grid h-12 w-12 place-items-center rounded-xl border border-line bg-mist text-navy-300">
          <Icon size={20} strokeWidth={1.6} />
        </span>
      )}
      <h4 className="font-display text-[15px] font-bold text-navy-800">{title}</h4>
      {body && <p className="mt-1.5 max-w-sm text-[13px] leading-relaxed text-navy-400">{body}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  )
}

// ---------------------------------------------
// Sparkline / Bars / Donut — رسوم SVG خفيفة بلا مكتبات
// ---------------------------------------------
export function Sparkline({ data = [], stroke = '#12A5A5', fill = 'rgba(18,165,165,.12)', height = 40 }) {
  if (!data.length) return null
  const w = 120
  const min = Math.min(...data)
  const max = Math.max(...data)
  const span = max - min || 1
  const step = w / (data.length - 1 || 1)
  const pts = data.map((v, i) => [i * step, height - 4 - ((v - min) / span) * (height - 10)])
  const line = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ')
  const area = `${line} L${w},${height} L0,${height} Z`
  return (
    <svg viewBox={`0 0 ${w} ${height}`} className="w-full" preserveAspectRatio="none" style={{ height }}>
      <path d={area} fill={fill} />
      <path d={line} fill="none" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="2.6" fill={stroke} />
    </svg>
  )
}

export function BarChart({ labels = [], values = [], color = '#0A2540', format = (v) => v }) {
  const max = Math.max(...values, 1)
  return (
    <div className="flex h-44 items-end gap-2">
      {values.map((v, i) => (
        <div key={i} className="group flex flex-1 flex-col items-center gap-2">
          <span className="num text-[10.5px] font-medium text-navy-400 opacity-0 transition-opacity group-hover:opacity-100">
            {format(v)}
          </span>
          <div className="relative flex w-full flex-1 items-end">
            <div
              className="w-full rounded-t-md transition-all duration-300 group-hover:opacity-80"
              style={{ height: `${(v / max) * 100}%`, background: color, minHeight: 4 }}
            />
          </div>
          <span className="text-[10.5px] text-navy-400">{labels[i]}</span>
        </div>
      ))}
    </div>
  )
}

export function Donut({ data = [], size = 148, thickness = 18 }) {
  const total = data.reduce((s, d) => s + d.value, 0) || 1
  const r = (size - thickness) / 2
  const c = 2 * Math.PI * r
  let offset = 0
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0">
      <g transform={`rotate(-90 ${size / 2} ${size / 2})`}>
        {data.map((d, i) => {
          const len = (d.value / total) * c
          const el = (
            <circle
              key={i}
              cx={size / 2}
              cy={size / 2}
              r={r}
              fill="none"
              stroke={d.color}
              strokeWidth={thickness}
              strokeDasharray={`${len} ${c - len}`}
              strokeDashoffset={-offset}
              strokeLinecap="butt"
            />
          )
          offset += len
          return el
        })}
      </g>
    </svg>
  )
}
