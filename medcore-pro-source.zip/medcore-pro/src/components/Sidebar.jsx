import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard, Users, Hourglass, Stethoscope, CalendarDays,
  Pill, FlaskConical, BarChart3, Settings, X, Activity,
} from 'lucide-react'
import { waitingList, alerts, currentUser, clinic } from '../data/mockData'

const nav = [
  { to: '/', label: 'الرئيسية', icon: LayoutDashboard, end: true },
  { to: '/patients', label: 'المرضى', icon: Users },
  { to: '/waiting', label: 'قائمة الانتظار', icon: Hourglass, count: waitingList.length },
  { to: '/visits', label: 'الزيارات', icon: Stethoscope },
  { to: '/appointments', label: 'المواعيد', icon: CalendarDays },
  { to: '/prescriptions', label: 'الوصفات', icon: Pill },
  { to: '/labs', label: 'الفحوصات', icon: FlaskConical, count: alerts.filter((a) => a.level === 'حرج').length },
  { to: '/reports', label: 'التقارير', icon: BarChart3 },
  { to: '/settings', label: 'الإعدادات', icon: Settings },
]

function Item({ item, onNavigate }) {
  const Icon = item.icon
  return (
    <NavLink
      to={item.to}
      end={item.end}
      onClick={onNavigate}
      className={({ isActive }) =>
        `group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13.5px] transition-colors ${
          isActive ? 'bg-white/[0.07] text-white' : 'text-navy-200/70 hover:bg-white/[0.04] hover:text-white'
        }`
      }
    >
      {({ isActive }) => (
        <>
          {/* مؤشر التبويب النشط — على الحافة اليمنى لأن الاتجاه من اليمين لليسار */}
          <span
            className={`absolute -right-3 top-1/2 h-6 w-[3px] -translate-y-1/2 rounded-full transition-all ${
              isActive ? 'bg-teal-400 opacity-100' : 'bg-teal-400 opacity-0'
            }`}
          />
          <Icon size={17} strokeWidth={isActive ? 2.1 : 1.7} className={isActive ? 'text-teal-300' : ''} />
          <span className={isActive ? 'font-semibold' : ''}>{item.label}</span>
          {item.count > 0 && (
            <span className="num ms-auto rounded-md bg-white/10 px-1.5 py-0.5 text-[10.5px] font-semibold text-white">
              {item.count}
            </span>
          )}
        </>
      )}
    </NavLink>
  )
}

export default function Sidebar({ open, onClose }) {
  return (
    <>
      {open && <div className="fixed inset-0 z-40 bg-navy-950/50 backdrop-blur-[2px] lg:hidden" onClick={onClose} />}

      <aside
        className={`fixed inset-y-0 right-0 z-50 flex w-[270px] flex-col bg-navy-950 grid-texture transition-transform duration-300 lg:translate-x-0 ${
          open ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* الهوية */}
        <div className="flex items-center gap-3 px-6 pb-5 pt-6">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-teal-400 to-teal-600 shadow-inset">
            <Activity size={20} strokeWidth={2.4} className="text-navy-950" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="font-display text-[15px] font-extrabold leading-tight text-white">
              MedCore <span className="text-teal-300">Pro</span>
            </p>
            <p className="truncate text-[11px] text-navy-300/70">{clinic.name}</p>
          </div>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-lg text-navy-300 hover:bg-white/5 lg:hidden" aria-label="إغلاق القائمة">
            <X size={16} />
          </button>
        </div>

        <div className="mx-6 h-px bg-white/[0.07]" />

        {/* التنقل */}
        <nav className="flex-1 overflow-y-auto px-6 py-5">
          <p className="mb-2 px-3 text-[10px] font-semibold tracking-[0.16em] text-navy-400/60">العمل اليومي</p>
          <div className="space-y-0.5">
            {nav.slice(0, 5).map((i) => (
              <Item key={i.to} item={i} onNavigate={onClose} />
            ))}
          </div>

          <p className="mb-2 mt-6 px-3 text-[10px] font-semibold tracking-[0.16em] text-navy-400/60">السجل الطبي</p>
          <div className="space-y-0.5">
            {nav.slice(5, 7).map((i) => (
              <Item key={i.to} item={i} onNavigate={onClose} />
            ))}
          </div>

          <p className="mb-2 mt-6 px-3 text-[10px] font-semibold tracking-[0.16em] text-navy-400/60">الإدارة</p>
          <div className="space-y-0.5">
            {nav.slice(7).map((i) => (
              <Item key={i.to} item={i} onNavigate={onClose} />
            ))}
          </div>
        </nav>

        {/* حالة العيادة */}
        <div className="mx-6 mb-6 rounded-xl border border-white/[0.07] bg-white/[0.03] p-3.5">
          <div className="flex items-center gap-2">
            <i className="h-1.5 w-1.5 animate-pulseDot rounded-full bg-teal-400" />
            <p className="text-[12px] font-semibold text-white">العيادة مفتوحة</p>
          </div>
          <p className="mt-1.5 text-[11.5px] leading-relaxed text-navy-300/70">
            {currentUser.name} — {waitingList.length} في الانتظار الآن
          </p>
        </div>
      </aside>
    </>
  )
}
