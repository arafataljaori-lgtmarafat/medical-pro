/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: '#06182B',
          soft: '#0A2540',
          mid: '#123456',
        },
        navy: {
          50: '#F2F6FB',
          100: '#E3EAF3',
          200: '#C3D2E4',
          300: '#95AECB',
          400: '#5F82AB',
          500: '#3C5F8C',
          600: '#284872',
          700: '#1B355A',
          800: '#0F2440',
          900: '#0A2540',
          950: '#06182B',
        },
        teal: {
          50: '#EDFBFA',
          100: '#D2F5F3',
          200: '#A6EBE7',
          300: '#6DD9D5',
          400: '#31C0BD',
          500: '#12A5A5',
          600: '#0B8586',
          700: '#0C6A6C',
          800: '#0E5456',
          900: '#0F4648',
        },
        gold: {
          50: '#FBF7EC',
          100: '#F5EBCE',
          200: '#EBD79C',
          300: '#DDBD64',
          400: '#C9A227',
          500: '#B08D1E',
          600: '#8D6E18',
          700: '#6B5314',
        },
        mist: '#F4F7FA',
        line: '#E3E9F0',
        clay: '#C2454A',
      },
      fontFamily: {
        display: ['Cairo', 'system-ui', 'sans-serif'],
        sans: ['"IBM Plex Sans Arabic"', 'Cairo', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
      },
      borderRadius: {
        xl: '14px',
        '2xl': '20px',
      },
      boxShadow: {
        card: '0 1px 2px rgba(6,24,43,0.04), 0 8px 24px -12px rgba(6,24,43,0.12)',
        lift: '0 2px 4px rgba(6,24,43,0.04), 0 24px 48px -20px rgba(6,24,43,0.28)',
        inset: 'inset 0 1px 0 rgba(255,255,255,0.06)',
      },
      keyframes: {
        rise: {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        pulseDot: {
          '0%,100%': { opacity: '1' },
          '50%': { opacity: '0.25' },
        },
        sweep: {
          '0%': { transform: 'translateX(100%)' },
          '100%': { transform: 'translateX(-100%)' },
        },
      },
      animation: {
        rise: 'rise .4s cubic-bezier(.22,1,.36,1) both',
        pulseDot: 'pulseDot 1.8s ease-in-out infinite',
        sweep: 'sweep 3.5s linear infinite',
      },
    },
  },
  plugins: [],
}
